<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="da">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>Om qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Author</source>
        <translation>Forfatter</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>Nuværende vedligeholder</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation>Grækenland</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation>Nationalitet:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation>Oprindelig forfatter</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation>Frankrig</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>Særlig tak til</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation>Oversættere</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="293"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="319"/>
        <source>Libraries</source>
        <translation>Biblioteker</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="325"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent blev bygget med følgende biblioteker:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="61"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>En avanceret BitTorrent-klient, programmeret in C++, baseret på Qt toolkit og libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="62"/>
        <source>Copyright %1 2006-2019 The qBittorrent project</source>
        <translation>Ophavsret %1 2006-2019 qBittorrent-projektet</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="63"/>
        <source>Home Page:</source>
        <translation>Hjemmeside:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="64"/>
        <source>Forum:</source>
        <translation>Forum:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.cpp" line="65"/>
        <source>Bug Tracker:</source>
        <translation>Fejltracker:</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Save at</source>
        <translation>Gem i</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="345"/>
        <source>Never show again</source>
        <translation>Vis aldrig igen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="99"/>
        <source>Torrent settings</source>
        <translation>Torrent-indstillinger</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="132"/>
        <source>Set as default category</source>
        <translation>Sæt som standardkategori</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="107"/>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="179"/>
        <source>Start torrent</source>
        <translation>Start torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="210"/>
        <source>Torrent information</source>
        <translation>Torrent-information</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="158"/>
        <source>Skip hash check</source>
        <translation>Spring hashtjek over</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="229"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="302"/>
        <source>Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="309"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="216"/>
        <source>Date:</source>
        <translation>Dato:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="41"/>
        <source>Torrent Management Mode:</source>
        <translation>Tilstand for torrent-håndtering:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="48"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automatisk tilstand betyder at diverse torrent-egenskaber (f.eks. gemmesti) vil blive besluttet af den tilknyttede kategori</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="52"/>
        <source>Manual</source>
        <translation>Manuelt</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="57"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="89"/>
        <source>Remember last used save path</source>
        <translation>Husk sidste anvendte gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="141"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Når den er tilvalgt, så slettes .torrent-filen ikke, ligegyldigt hvad indstillingen på &quot;Download&quot;-siden er sat til i indstillinger-dialogen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Do not delete .torrent file</source>
        <translation>Slet ikke .torrent-filen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="172"/>
        <source>Create subfolder</source>
        <translation>Opret undermappe</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="165"/>
        <source>Download in sequential order</source>
        <translation>Download i fortløbende rækkefølge</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="151"/>
        <source>Download first and last pieces first</source>
        <translation>Start med at downloade første og sidste stykker</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="407"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="412"/>
        <source>High</source>
        <translation>Høj</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="417"/>
        <source>Maximum</source>
        <translation>Højeste</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="422"/>
        <source>Do not download</source>
        <translation>Download ikke</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="571"/>
        <source>I/O Error</source>
        <translation>I/O-fejl</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="261"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="646"/>
        <source>Invalid torrent</source>
        <translation>Ugyldig torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="597"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Ikke tilgængelig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="598"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Ikke tilgængelig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="606"/>
        <source>Not available</source>
        <translation>Ikke tilgængelig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="305"/>
        <source>Invalid magnet link</source>
        <translation>Ugyldigt magnet-link</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="262"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Kunne ikke indlæse torrenten: %1.
Fejl: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="305"/>
        <source>This magnet link was not recognized</source>
        <translation>Dette magnet-link blev ikke genkendt</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="334"/>
        <source>Magnet link</source>
        <translation>Magnet-link</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="340"/>
        <source>Retrieving metadata...</source>
        <translation>Modtager metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="100"/>
        <source>Choose save path</source>
        <translation>Vælg gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="282"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="287"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="291"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="316"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="321"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>Torrent is already present</source>
        <translation>Torrent findes allerede</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="282"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="316"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation>Torrenten &apos;%1&apos; er allerede i overførselslisten. Trackere blev ikke lagt sammen da det er en privat torrent.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="287"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>Torrenten &apos;%1&apos; er allerede i overførselslisten. Trackere blev lagt sammen.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="291"/>
        <source>Torrent is already queued for processing.</source>
        <translation>Torrenten er allerede sat i kø til behandling.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="321"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation>Magnet-linket &apos;%1&apos; er allerede i overførselslisten. Trackere blev lagt sammen.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>Magnet link is already queued for processing.</source>
        <translation>Magnet-linket er allerede sat i kø til behandling.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="403"/>
        <source>%1 (Free space on disk: %2)</source>
        <translation>%1 (ledig plads på disk: %2)</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="404"/>
        <source>Not available</source>
        <comment>This size is unavailable.</comment>
        <translation>Ikke tilgængelig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="666"/>
        <source>Cannot download &apos;%1&apos;: %2</source>
        <translation>Kan ikke downloade &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="475"/>
        <source>Rename...</source>
        <translation>Omdøb...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="481"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="572"/>
        <source>Invalid metadata</source>
        <translation>Ugyldig metadata</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="579"/>
        <source>Parsing metadata...</source>
        <translation>Fortolker  metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="583"/>
        <source>Metadata retrieval complete</source>
        <translation>Modtagelse af metadata er færdig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="646"/>
        <source>Failed to load from URL: %1.
Error: %2</source>
        <translation>Kunne ikke indlæse fra URL: %1.
Fejl: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="665"/>
        <source>Download Error</source>
        <translation>Fejl ved download</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="274"/>
        <location filename="../gui/advancedsettings.cpp" line="397"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="468"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Udgående porte (Min.) [0: Deaktiveret]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="473"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Udgående porte (Maks.) [0: Deaktiveret]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="485"/>
        <source>Recheck torrents on completion</source>
        <translation>Gentjek torrents når de er færdige</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="491"/>
        <source>Transfer list refresh interval</source>
        <translation>Opdateringsinterval for overførselsliste</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="490"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="129"/>
        <source>Setting</source>
        <translation>Indstilling</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="129"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Værdi</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="270"/>
        <location filename="../gui/advancedsettings.cpp" line="282"/>
        <source> (disabled)</source>
        <translation> (deaktiveret)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="272"/>
        <source> (auto)</source>
        <translation> (automatisk)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="280"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="293"/>
        <source>All addresses</source>
        <translation>Alle adresser</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="335"/>
        <source>qBittorrent Section</source>
        <translation>qBittorrent-sektion</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="332"/>
        <location filename="../gui/advancedsettings.cpp" line="340"/>
        <source>Open documentation</source>
        <translation>Åbn dokumentation</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="294"/>
        <source>All IPv4 addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="295"/>
        <source>All IPv6 addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="343"/>
        <source>libtorrent Section</source>
        <translation>libtorrent-sektion</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Below normal</source>
        <translation>Under normal</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Low</source>
        <translation>Lav</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Very low</source>
        <translation>Meget lav</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="368"/>
        <source>Process memory priority (Windows &gt;= 8 only)</source>
        <translation>Prioritet for proceshukommelse (kun Windows &gt;= 8)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="377"/>
        <source>Asynchronous I/O threads</source>
        <translation>Asynkrone I/O-tråde</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="384"/>
        <source>File pool size</source>
        <translation>Filsamlingsstørrelse</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="398"/>
        <source>Outstanding memory when checking torrents</source>
        <translation>Udestående hukommelse ved tjek af torrents</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="412"/>
        <source>Disk cache</source>
        <translation>Diskmellemlager</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="418"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="419"/>
        <source>Disk cache expiry interval</source>
        <translation>Udløbsinterval for diskmellemlager</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="423"/>
        <source>Enable OS cache</source>
        <translation>Aktivér OS-mellemlager</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="427"/>
        <source>Coalesce reads &amp; writes</source>
        <translation>Coalesce-læsninger og -skrivninger</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="431"/>
        <source>Send upload piece suggestions</source>
        <translation>Send forslag for upload-styk</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="436"/>
        <location filename="../gui/advancedsettings.cpp" line="442"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="438"/>
        <source>Send buffer watermark</source>
        <translation>Send vandmærke for buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="444"/>
        <source>Send buffer low watermark</source>
        <translation>Send vandmærke for lav buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="450"/>
        <source>Send buffer watermark factor</source>
        <translation>Send vandmærkefaktor for buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="456"/>
        <source>Socket backlog size</source>
        <translation>Størrelse for sokkel baglog</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="475"/>
        <source>Prefer TCP</source>
        <translation>Foretræk TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="475"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation>Modpartsproportionel (drosler TCP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="482"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Tillad flere forbindelser fra den samme IP-adresse</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="494"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Oversæt modparters lande (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="497"/>
        <source>Resolve peer host names</source>
        <translation>Oversæt modparters værtsnavne</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="500"/>
        <source>Strict super seeding</source>
        <translation>Streng superseeding</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="520"/>
        <source>Network Interface (requires restart)</source>
        <translation>Netværksgrænseflade (kræver genstart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="523"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>Valgfri IP-adresse som der skal bindes til (kræver genstart)</translation>
    </message>
    <message>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation type="vanished">Lyt på IPv6-adresse (kræver genstart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="531"/>
        <source>Display notifications</source>
        <translation>Vis underretninger</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="534"/>
        <source>Display notifications for added torrents</source>
        <translation>Vis underretninger for tilføjede torrents</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="537"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Download trackerens favicon</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="541"/>
        <source>Save path history length</source>
        <translation>Historiklængde for gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="544"/>
        <source>Enable speed graphs</source>
        <translation>Aktivér hastighedsgrafer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="554"/>
        <source>Fixed slots</source>
        <translation>Fastgjorte pladser</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="554"/>
        <source>Upload rate based</source>
        <translation>Baseret på uploadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="556"/>
        <source>Upload slots behavior</source>
        <translation>Opførsel for uploadpladser</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="559"/>
        <source>Round-robin</source>
        <translation>Round-robin</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="559"/>
        <source>Fastest upload</source>
        <translation>Hurtigste upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="559"/>
        <source>Anti-leech</source>
        <translation>Anti-leech</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="561"/>
        <source>Upload choking algorithm</source>
        <translation>Upload choking-algoritme</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="570"/>
        <source>Confirm torrent recheck</source>
        <translation>Bekræft gentjek af torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="574"/>
        <source>Confirm removal of all tags</source>
        <translation>Bekræft fjernelse af alle mærkater</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="578"/>
        <source>Always announce to all trackers in a tier</source>
        <translation>Annoncér altid til alle trackere i en tier</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="582"/>
        <source>Always announce to all tiers</source>
        <translation>Annoncér altid til alle tiers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="503"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Vilkårlig grænseflade</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="463"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Gemmeinterval for genoptagelsesdata</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="477"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>%1-TCP blandet-tilstand-algoritme</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="526"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP-adresse der reporteres til tracker (kræver genstart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="547"/>
        <source>Enable embedded tracker</source>
        <translation>Aktivér indlejret tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="552"/>
        <source>Embedded tracker port</source>
        <translation>Indlejret tracker-port</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="566"/>
        <source>Use system icon theme</source>
        <translation>Brug systemets ikontema</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="173"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 startet</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="175"/>
        <source>Running in portable mode. Auto detected profile folder at: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="177"/>
        <source>Redundant command line flag detected: &quot;%1&quot;. Portable mode implies relative fastresume.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="180"/>
        <source>Using config directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="332"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, kører eksternt program, kommando: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="363"/>
        <source>Torrent name: %1</source>
        <translation>Torrentnavn: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="364"/>
        <source>Torrent size: %1</source>
        <translation>Torrentstørrelse: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="365"/>
        <source>Save path: %1</source>
        <translation>Gemmesti: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="366"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrenten blev downloadet på %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="368"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Tak fordi du bruger qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="375"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; er færdig med at downloade</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="389"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, sender underretning via e-mail</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="549"/>
        <source>Application failed to start.</source>
        <translation>Programmet kunne ikke starte.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="562"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="563"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation>Styr qBittorrent, ved at tilgå webgrænsefladen på %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="568"/>
        <source>The Web UI administrator username is: %1</source>
        <translation>Webgrænsefladens administratorbrugernavn er: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="569"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Webgrænsefladens administratorens adgangskode er stadig den som er standard: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="570"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Dette er en sikkerhedsrisiko, overvej venligst at skifte adgangskoden via programpræferencerne.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="697"/>
        <source>Saving torrent progress...</source>
        <translation>Gemmer torrentforløb...</translation>
    </message>
    <message>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation type="vanished">Transportabeltilstand og eksplicitte valgmuligheder for profilmappe er gensidigt eksplicitte</translation>
    </message>
    <message>
        <source>Portable mode implies relative fastresume</source>
        <translation type="vanished">Transportabeltilstand indebærer relativ hurtig genoptagelse</translation>
    </message>
</context>
<context>
    <name>AsyncFileStorage</name>
    <message>
        <location filename="../base/asyncfilestorage.cpp" line="41"/>
        <source>Could not create directory &apos;%1&apos;.</source>
        <translation>Kunne ikke oprette mappen &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="55"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation>WebAPI-login mislykkedes. Årsag: IP er blevet udelukket, IP: %1, brugernavn: %2</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="59"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Din IP-adresse er blevet udelukket efter for mange mislykkede godkendelsesforsøg.</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="74"/>
        <source>WebAPI login success. IP: %1</source>
        <translation>WebAPI-login lykkedes. IP: %1</translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="79"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation>WebAPI-login mislykkedes. Årsag: ugyldige loginoplysninger, antal forsøg: %1, IP: %2, brugernavn: %3</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="240"/>
        <source>Save to:</source>
        <translation>Gem i:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>RSS-downloader</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>Automatisk download af RSS-torrents er nu deaktiveret! Du kan aktivere det i programindstillingerne.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Downloadregler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Regeldefinition</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Brug regulære udtryk</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.01.01 and 01.01.2017 (Date formats also support - as a separator)</source>
        <translation>Smart episodefilter tjekker episodenummeret for at hindre download af duplikater.
Understøtter formaterne: S01E01, 1x1, 2017.01.01 og 01.01.2017 (datoformater understøtter også - som en separator)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation>Brug smart episodefilter</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Skal indeholde:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>Skal ikke indeholde:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Episodefilter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Assign Category:</source>
        <translation>Tildel kategori:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="228"/>
        <source>Save to a Different Directory</source>
        <translation>Gem i en anden mappe</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="254"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignorer efterfølgende match for (0 for at deaktivere)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="264"/>
        <source>Disabled</source>
        <translation>Deaktiveret</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="267"/>
        <source> days</source>
        <translation> dage</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="300"/>
        <source>Add Paused:</source>
        <translation>Tilføj sat på pause:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="308"/>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="344"/>
        <source>Use global settings</source>
        <translation>Brug globale indstillinger</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="313"/>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="349"/>
        <source>Always</source>
        <translation>Altid</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="318"/>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="354"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="336"/>
        <source>Create Subfolder:</source>
        <translation>Opret undermappe:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="375"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Anvend regel på feeds:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="397"/>
        <source>Matching RSS Articles</source>
        <translation>Matchende RSS-artikler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="425"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importér...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="435"/>
        <source>&amp;Export...</source>
        <translation>&amp;Eksportér...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Matcher artikler baseret på episodefilter.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Example: </source>
        <translation>Eksempel: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation> matcher episode 2, 5, 8 op til 15, 30 og videre for sæson 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Episode filter rules: </source>
        <translation>Regler for episodefilter: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Sæsonnummer er en obligatorisk ikke-nul-værdi</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source>Filter must end with semicolon</source>
        <translation>Filter skal slutte med semikolon</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Der understøttes tre områdetyper for episoder: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Ét nummer: &lt;b&gt;1x25;&lt;/b&gt; matcher episode 25 for sæson 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="95"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Normalt område: &lt;b&gt;1x25-40;&lt;/b&gt; matcher episode 25 til 40 for sæson 1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>Episodenummer er en obligatorisk positiv værdi</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="62"/>
        <source>Rules</source>
        <translation>Regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="63"/>
        <source>Rules (legacy)</source>
        <translation>Regler (udgået)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="96"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Uendeligt område: &lt;b&gt;1x25-;&lt;/b&gt; matcher episode 25 og op for sæson 1 og alle episoder for senere sæsoner</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="282"/>
        <source>Last Match: %1 days ago</source>
        <translation>Sidste match: %1 dage siden</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="284"/>
        <source>Last Match: Unknown</source>
        <translation>Sidste match: Ukendt</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="375"/>
        <source>New rule name</source>
        <translation>Nyt regelnavn</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="375"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Skriv venligst navnet på den nye downloadregel.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="524"/>
        <source>Rule name conflict</source>
        <translation>Konflikt for regelnavn</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="381"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="525"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Der findes allerede en regel med dette navn, vælg venligst et andet navn.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="395"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Er du sikker på, at du vil fjerne downloadreglen med navnet &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="397"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Er du sikker på, at du vil fjerne de valgte downloadregler?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="398"/>
        <source>Rule deletion confirmation</source>
        <translation>Bekræftelse for sletning af regel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="80"/>
        <source>Destination directory</source>
        <translation>Destinationsmappe</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="408"/>
        <source>Invalid action</source>
        <translation>Ugyldig handling</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="409"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Listen er tom. Der er intet at eksportere.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="415"/>
        <source>Export RSS rules</source>
        <translation>Eksportér RSS-regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="438"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="455"/>
        <source>I/O Error</source>
        <translation>I/O-fejl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="439"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>Kunne ikke oprette destinationsfilen. Årsag: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="447"/>
        <source>Import RSS rules</source>
        <translation>Importér RSS-regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="456"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>Kunne ikke åbne filen. Årsag: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="471"/>
        <source>Import Error</source>
        <translation>Fejl ved import</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="472"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>Kunne ikke importere den valgte regelfil. Årsag: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="481"/>
        <source>Add new rule...</source>
        <translation>Tilføj ny regel...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="488"/>
        <source>Delete rule</source>
        <translation>Slet regel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="493"/>
        <source>Rename rule...</source>
        <translation>Omdøb regel...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="497"/>
        <source>Delete selected rules</source>
        <translation>Slet valgte regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="503"/>
        <source>Clear downloaded episodes...</source>
        <translation>Ryd downloadede episoder...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="518"/>
        <source>Rule renaming</source>
        <translation>Omdøbning af regel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="518"/>
        <source>Please type the new rule name</source>
        <translation>Skriv venligst det nye regelnavn</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="544"/>
        <source>Clear downloaded episodes</source>
        <translation>Ryd downloadede episoder</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="545"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Er du sikker på, at du vil rydde listen over downloadede episoder for den valgte regel?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="649"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regulært udtryk-tilstand: brug Perl-kompatible regulære udtryk</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="691"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="729"/>
        <source>Position %1: %2</source>
        <translation>Placering %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="652"/>
        <source>Wildcard mode: you can use</source>
        <translation>Jokertegnstilstand: du kan bruge</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="653"/>
        <source>? to match any single character</source>
        <translation>? for at matche ét tegn</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="654"/>
        <source>* to match zero or more of any characters</source>
        <translation>* for at matche nul eller flere tegn</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="655"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Blanktegn tæller som OG-operatører (alle ord, vilkårlig rækkefølge)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="656"/>
        <source>| is used as OR operator</source>
        <translation>| bruges som en ELLER-operatør</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="657"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Hvis rækkefølgen på ord er vigtig, så brug * i stedet for blanktegn.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="664"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Et udtryk med et tomt %1-klausul (f.eks. %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="668"/>
        <source> will match all articles.</source>
        <translation> vil matche alle artikler.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="669"/>
        <source> will exclude all articles.</source>
        <translation> vil ekskludere alle artikler.</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>Liste med udelukkede IP-adresser</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="80"/>
        <source>Ban IP</source>
        <translation>Udeluk IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="87"/>
        <source>Delete</source>
        <translation>Slet</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <source>The entered IP address is invalid.</source>
        <translation>Den indtastede IP-adresse er ugyldig.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>The entered IP is already banned.</source>
        <translation>Den indtastede IP er allerede udelukket.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Genstart kræves for at slå understøttelse af PeX til/fra</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2509"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Systemets netværksstatus ændret til %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2509"/>
        <source>ONLINE</source>
        <translation>ONLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2509"/>
        <source>OFFLINE</source>
        <translation>OFFLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2522"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>Netværkskonfiguration af %1 er blevet ændret, genopfrisker sessionsbinding</translation>
    </message>
    <message>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation type="vanished">Konfigureret netværksgrænsefladeadresse %1 er ikke gyldig.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1112"/>
        <location filename="../base/bittorrent/session.cpp" line="2873"/>
        <source>Encryption support [%1]</source>
        <translation>Understøttelse af kryptering [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1113"/>
        <location filename="../base/bittorrent/session.cpp" line="2874"/>
        <source>FORCED</source>
        <translation>TVUNGET</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2984"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 er ikke en gyldig IP-adresse og blev afvist under anvendelse af listen over udelukkede adresser.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1111"/>
        <location filename="../base/bittorrent/session.cpp" line="3321"/>
        <source>Anonymous mode [%1]</source>
        <translation>Anonym tilstand [%1]</translation>
    </message>
    <message>
        <source>Trying to listen on IP: %1, port: %2</source>
        <comment>e.g: Trying to listen on IP: 192.168.0.1, port: 6881</comment>
        <translation type="vanished">Prøver at lytte på IP: %1, port: %2</translation>
    </message>
    <message>
        <source>Could not get GUID of configured network interface. Binding to IP: %1</source>
        <translation type="vanished">Kunne ikke få GUID af konfigureret netværksgrænseflade. Binder til IP: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1642"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed torrent and its files.</source>
        <translation>&apos;%1&apos; nåede det maksimale forhold som du har sat. Fjernede torrent og dens filer.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1651"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Enabled super seeding for it.</source>
        <translation>&apos;%1&apos; nåede det maksimale forhold som du har sat. Aktiverede superseeding for den.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1673"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed torrent and its files.</source>
        <translation>&apos;%1&apos; nåede det maksimale seedingtid som du har sat. Fjernede torrent og dens filer.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1682"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Enabled super seeding for it.</source>
        <translation>&apos;%1&apos; nåede det maksimale seedingtid som du har sat. Aktiverede superseeding for den.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2430"/>
        <source>Error: Aborted saving resume data for %1 outstanding torrents.</source>
        <translation>Fejl: Afbrød gemning af genoptagelsesdata for %1 udestående torrents.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2538"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.158.1 isn&apos;t valid.</comment>
        <translation type="unfinished">Konfigureret netværksgrænsefladeadresse %1 er ikke gyldig.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2572"/>
        <location filename="../base/bittorrent/session.cpp" line="2604"/>
        <source>Can&apos;t find the configured address &apos;%1&apos; to listen on</source>
        <comment>Can&apos;t find the configured address &apos;192.168.1.3&apos; to listen on</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3792"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Kan ikke dekode &apos;%1&apos; torrent-fil.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3936"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Rekursiv download af filen &apos;%1&apos; indlejret i torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4039"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation>Køplaceringer blev rettet i %1 resume-filer</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4271"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>Kunne ikke gemme &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4298"/>
        <source>Torrent errored. Torrent: &quot;%1&quot;. Error: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4327"/>
        <location filename="../base/bittorrent/session.cpp" line="4364"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; blev fjernet fra overførselslisten.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4342"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; blev fjernet fra overførselslisten og harddisken.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4359"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; blev fjernet fra overførselslisten men filerne kunne ikke slettes. Fejl: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4417"/>
        <source>File error alert. Torrent: &quot;%1&quot;. File: &quot;%2&quot;. Reason: %3</source>
        <translation>Alarmering om filfejl. Torrent: &quot;%1&quot;. Fil: &quot;%2&quot;. Årsag: %3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4460"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>fordi %1 er deaktiveret.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4463"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>fordi %1 er deaktiveret.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4491"/>
        <source>URL seed name lookup failed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Error: &quot;%3&quot;</source>
        <translation>Opslag af URL-seednavn mislykkedes. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Fejl: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4496"/>
        <source>Received error message from a URL seed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Message: &quot;%3&quot;</source>
        <translation>Modtog fejlmeddelelse fra en URL-seed. Torrent: &quot;%1&quot;. URL: &quot;%2&quot;. Meddelelse: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4552"/>
        <source>Successfully listening on IP: %1, port: %2/%3</source>
        <comment>e.g: Successfully listening on IP: 192.168.0.1, port: TCP/6881</comment>
        <translation>Lytter på IP: %1, port: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4615"/>
        <source>Failed to listen on IP: %1, port: %2/%3. Reason: %4</source>
        <comment>e.g: Failed to listen on IP: 192.168.0.1, port: TCP/6881. Reason: already in use</comment>
        <translation>Kunne ikke lytte på IP: %1, port: %2/%3. Årsag: %4</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4629"/>
        <source>Detected external IP: %1</source>
        <comment>e.g. Detected external IP: 1.1.1.1</comment>
        <translation>Registreret ekstern IP: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4708"/>
        <source>Error: Internal alert queue full and alerts were dropped, you might see degraded performance. Dropped alert types: %1. Message: %2</source>
        <translation>Fejl: Intern alarmeringskø fuld og alarmeringer blev droppet, du kan opleve nedsat ydelse. Droppet alarmeringstyper: %1. Meddelelse: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1946"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Downloader &apos;%1&apos;, vent venligst...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2585"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>Den angivne netværksgrænseflade er ugyldig: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1106"/>
        <source>Peer ID: </source>
        <translation>Modparts-ID: </translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1107"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>HTTP User-Agent er &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="554"/>
        <location filename="../base/bittorrent/session.cpp" line="1108"/>
        <source>DHT support [%1]</source>
        <translation>Understøttelse af DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="554"/>
        <location filename="../base/bittorrent/session.cpp" line="568"/>
        <location filename="../base/bittorrent/session.cpp" line="1108"/>
        <location filename="../base/bittorrent/session.cpp" line="1109"/>
        <location filename="../base/bittorrent/session.cpp" line="1110"/>
        <location filename="../base/bittorrent/session.cpp" line="1111"/>
        <location filename="../base/bittorrent/session.cpp" line="1112"/>
        <location filename="../base/bittorrent/session.cpp" line="2874"/>
        <location filename="../base/bittorrent/session.cpp" line="3321"/>
        <source>ON</source>
        <translation>TIL</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="554"/>
        <location filename="../base/bittorrent/session.cpp" line="568"/>
        <location filename="../base/bittorrent/session.cpp" line="1108"/>
        <location filename="../base/bittorrent/session.cpp" line="1109"/>
        <location filename="../base/bittorrent/session.cpp" line="1110"/>
        <location filename="../base/bittorrent/session.cpp" line="1111"/>
        <location filename="../base/bittorrent/session.cpp" line="1113"/>
        <location filename="../base/bittorrent/session.cpp" line="2874"/>
        <location filename="../base/bittorrent/session.cpp" line="3321"/>
        <source>OFF</source>
        <translation>FRA</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="568"/>
        <location filename="../base/bittorrent/session.cpp" line="1109"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Understøttelse af lokal modpartsopdagelse [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1110"/>
        <source>PeX support [%1]</source>
        <translation>Understøttelse af PeX [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1470"/>
        <location filename="../base/bittorrent/session.cpp" line="1490"/>
        <source>Could not get GUID of network interface: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1499"/>
        <source>Trying to listen on: %1</source>
        <comment>e.g: Trying to listen on: 192.168.0.1:6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1638"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; nåede det maksimale forhold som du har sat. Fjernet.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1647"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; nåede det maksimale forhold som du har sat. Sat på pause.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1669"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; nåede den maksimale seedingtid som du har sat. Fjernet.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1678"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; nåede den maksimale seedingtid som du har sat. Sat på pause.</translation>
    </message>
    <message>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation type="vanished">qBittorrent fandt ikke en lokal %1-adresse at lytte på</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3697"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Tracker &apos;%1&apos; blev tilføjet til torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3709"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Tracker &apos;%1&apos; blev slettet fra torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3726"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>URL-seed &apos;%1&apos; blev tilføjet til torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3733"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>URL-seed &apos;%1&apos; blev fjernet fra torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3871"/>
        <source>Cannot write to torrent resume folder.</source>
        <translation>Kan ikke skrive til rottent-genoptagelsesmappen.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3875"/>
        <source>Cannot create torrent resume folder.</source>
        <translation>Kan ikke oprette rottent-genoptagelsesmappen.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3982"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Kan ikke genoptage torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4058"/>
        <source>Couldn&apos;t load torrents queue from &apos;%1&apos;. Error: %2</source>
        <translation>Kunne ikke indlæse torrentens kø fra &apos;%1&apos;. Fejl: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4106"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Behandling af det angivne IP-filter lykkedes: %1 regler blev anvendt.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4116"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Fejl: Kunne ikke behandle det angivne IP-filter.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4257"/>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation>&apos;%1&apos; gendannet.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4306"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Kunne ikke tilføje torrent. Årsag: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4278"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; tilføjet til downloadlisten.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4428"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Fejl ved kortlægning af port, meddelelse: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4434"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Kortlægning af port lykkedes, meddelelse: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4448"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>pga. IP-filter.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4451"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>pga. port-filter.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4454"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>pga. restriktioner i i2p blandet-tilstand.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4457"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>fordi den har en lav port.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="193"/>
        <source>create new torrent file failed</source>
        <translation>oprettelse af torrent-fil mislykkedes</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="556"/>
        <source>Failed to add peer &quot;%1&quot; to torrent &quot;%2&quot;. Reason: %3</source>
        <translation>Kunne ikke tilføje modparten &quot;%1&quot; til torrenten &quot;%2&quot;. Årsag: %3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="561"/>
        <source>Peer &quot;%1&quot; is added to torrent &quot;%2&quot;</source>
        <translation>Modparten &quot;%1&quot; blev tilføjet til torrenten &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1484"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation>Start med at downloade første og sidste stykker: %1, torrent: &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1485"/>
        <source>On</source>
        <translation>Tændt</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1485"/>
        <source>Off</source>
        <translation>Slukket</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1613"/>
        <source>Successfully moved torrent: %1. New path: %2</source>
        <translation>Flyttede torrent: %1. Ny sti: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1648"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>Kunne ikke flytte torrent: &apos;%1&apos;. Årsag: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1847"/>
        <source>Save resume data failed. Torrent: &quot;%1&quot;, error: &quot;%2&quot;</source>
        <translation>Gemning af genoptagelsesdata mislykkedes. Torrent: &quot;%1&quot;, fejl: &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1860"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>Filstørrelser matcher ikke for torrent &apos;%1&apos;, pauser den.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1863"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Hurtig genoptagelsesdata blev afvist for torrent &apos;%1&apos;. Årsag: %2. Tjekker igen...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1916"/>
        <source>File rename failed. Torrent: &quot;%1&quot;, file: &quot;%2&quot;, reason: &quot;%3&quot;</source>
        <translation>Filomdøbning mislykkedes. Torrent: &quot;%1&quot;, fil: &quot;%2&quot;, årsag: &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1980"/>
        <source>Performance alert: </source>
        <translation>Ydelsesalarmering:</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Tracker</name>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="215"/>
        <source>Embedded Tracker: Now listening on IP: %1, port: %2</source>
        <translation>Indlejret tracker: Lytter nu på IP: %1, port: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/tracker.cpp" line="219"/>
        <source>Embedded Tracker: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Indlejret tracker: Kan ikke binde til IP: %1, port: %2. Årsag: %3</translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="241"/>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="395"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="402"/>
        <source>Uncategorized</source>
        <translation>Ukategoriseret</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="114"/>
        <source>Add category...</source>
        <translation>Tilføj kategori...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="122"/>
        <source>Add subcategory...</source>
        <translation>Tilføj underkategori...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="128"/>
        <source>Edit category...</source>
        <translation>Rediger kategori...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Remove category</source>
        <translation>Fjern kategori</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="139"/>
        <source>Remove unused categories</source>
        <translation>Fjern ubrugte kategorier</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="146"/>
        <source>Resume torrents</source>
        <translation>Genoptag torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="151"/>
        <source>Pause torrents</source>
        <translation>Sæt torrents på pause</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="156"/>
        <source>Delete torrents</source>
        <translation>Slet torrents</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Håndter cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Domæne</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Værdi</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Udløbsdato</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Bekræftelse for sletning</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Husk valg</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="91"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Slet også filerne på harddisken</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="44"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Er du sikker på, at du vil slette &apos;%1&apos; fra overførselslisten?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.cpp" line="46"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Er du sikker på, at du vil slette disse %1 torrents fra overførselslisten?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Download fra URL&apos;er</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Tilføj torrent-links</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Ét link pr. linje (understøtter HTTP-links, magnet-links og info-hashes)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="63"/>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="107"/>
        <source>No URL entered</source>
        <translation>Der er ikke indtastet nogen URL</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="107"/>
        <source>Please type at least one URL.</source>
        <translation>Skriv venligst mindst én URL.</translation>
    </message>
</context>
<context>
    <name>DownloadHandlerImpl</name>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="127"/>
        <source>I/O Error</source>
        <translation>Fejl ved I/O</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="143"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>Filstørrelsen er %1. Den overstiger grænsen for download af %2.</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="162"/>
        <source>Redirected to magnet URI.</source>
        <translation>Videresendt til magnet-URI.</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="186"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>Fjernværtsnavnet blev ikke fundet (ugyldigt værtsnavn)</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="188"/>
        <source>The operation was canceled</source>
        <translation>Handlingen blev annulleret</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="190"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>Fjernserveren lukkede forbindelsen for tidligt, før hele svaret blev modtaget og behandlet</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="192"/>
        <source>The connection to the remote server timed out</source>
        <translation>Forbindelsen til fjernserveren fik timeout</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="194"/>
        <source>SSL/TLS handshake failed</source>
        <translation>SSL/TLS-håndtryk mislykkedes</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="196"/>
        <source>The remote server refused the connection</source>
        <translation>Fjernserveren nægtede forbindelsen</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="198"/>
        <source>The connection to the proxy server was refused</source>
        <translation>Forbindelsen til proxyen blev nægtet</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="200"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>Proxyserveren lukkede forbindelsen for tidligt</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="202"/>
        <source>The proxy host name was not found</source>
        <translation>Proxyværtsnavnet blev ikke fundet</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="204"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Forbindelsen til proxyen fik timeout eller proxyen svarede ikke på den sendte anmodning i tide</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="206"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>Proxyen kræver godkendelse for at kunne efterleve anmodningen men accepterede ikke loginoplysninger</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="208"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>Adgangen til fjernindholdet blev nægtet (401)</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="210"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>Den anmodede handling er ikke tilladt på fjernindholdet</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="212"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>Fjernindholdet blev ikke fundet på serveren (404)</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="214"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>Fjernserveren kræve godkendelse for at kunne vise indholdet, men loginoplysningerne blev ikke accepteret</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="216"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>Netværksadgangs-API&apos;et kan ikke efterleve anmodningen  fordi protokollen ikke kendes</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="218"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>Den anmodet handling er ugyldig til protokollen</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="220"/>
        <source>An unknown network-related error was detected</source>
        <translation>Der blev registreret en ukendt netværksrelateret fejl</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="222"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Der blev registreret en ukendt proxyrelateret fejl</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="224"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Der blev registreret en ukendt fejl med relation til fjernindholdet</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="226"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Der blev registreret et nedbrud i protokollen</translation>
    </message>
    <message>
        <location filename="../base/net/private/downloadhandlerimpl.cpp" line="228"/>
        <source>Unknown error</source>
        <translation>Ukendt fejl</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="175"/>
        <source>White: Missing pieces</source>
        <translation>Hvid: Manglende stykker</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="176"/>
        <source>Green: Partial pieces</source>
        <translation>Grøn: Delvise stykker</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>Blue: Completed pieces</source>
        <translation>Blå: Komplette  stykker</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="36"/>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="42"/>
        <source>Blocked IPs</source>
        <translation>Blokerede IP&apos;er</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="103"/>
        <source>%1 was blocked %2</source>
        <comment>0.0.0.0 was blocked due to reason</comment>
        <translation>%1 blev blokeret %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="104"/>
        <source>%1 was banned</source>
        <comment>0.0.0.0 was banned</comment>
        <translation>%1 blev udelukket</translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="50"/>
        <source>RSS feeds</source>
        <translation>RSS-feeds</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="62"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="111"/>
        <source>Unread  (%1)</source>
        <translation>Ulæst (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="164"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation>Der opstod en fejl ved forsøg på at åbne logfilen. Logning til fil er deaktiveret.</translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="58"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="60"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Gennemse...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="62"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Vælg en fil</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="64"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Vælg en mappe</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="103"/>
        <source>Any file</source>
        <translation>Alle filer</translation>
    </message>
</context>
<context>
    <name>FileSystemWatcher</name>
    <message>
        <location filename="../base/filesystemwatcher.cpp" line="81"/>
        <source>Watching remote folder: &quot;%1&quot;</source>
        <translation>Holder øje med fjernmappe: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../base/filesystemwatcher.cpp" line="90"/>
        <source>Watching local folder: &quot;%1&quot;</source>
        <translation>Holder øje med lokal mappe: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="128"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="275"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="436"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>I/O-fejl: Kunne ikke åbne IP-filterfil i læsetilstand.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="212"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="342"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="351"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>IP-filterets linje %1 er udformeret forkert.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="221"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="360"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>IP-filterets linje %1 er udformeret forkert. Områdets start-IP er udformeret forkert.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="230"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="369"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>IP-filterets linje %1 er udformeret forkert. Områdets slut-IP er udformeret forkert.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="238"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="377"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>IP-filterets linje %1 er udformeret forkert. En IP er IPv4 og den anden er IPv6!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="252"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="390"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>IP-filter-undtagelse smidt for linje %1. Undtagelsen er: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="262"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="400"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation>%1 ekstra IP-filter fortolkningsfejl opstod.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="447"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="459"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="480"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="489"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="499"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="509"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="529"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Fejl ved fortolkning: Filterfilen er ikke en gyldig PeerGuardian P2B-fil.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="93"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="123"/>
        <source>Unsupported database file size.</source>
        <translation>Databasens filstørrelse understøttes ikke.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="221"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Fejl ved metadata: &apos;%1&apos;-elementet blev ikke fundet.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="222"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Fejl ved metadata: &apos;%1&apos;-elementet har ugyldig type.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="231"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Databaseversionen understøttes ikke: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="238"/>
        <source>Unsupported IP version: %1</source>
        <translation>IP-version understøttes ikke: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="245"/>
        <source>Unsupported record size: %1</source>
        <translation>Record-størrelse understøttes ikke: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="258"/>
        <source>Invalid database type: %1</source>
        <translation>Ugyldig databasetype: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="279"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Databasen er ødelagt: intet dataafsnit blev fundet.</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="69"/>
        <source>Http request size exceeds limiation, closing socket. Limit: %1, IP: %2</source>
        <translation>Http-anmodningsstørrelse overstiger begrænsning. Lukke sokkel. Grænse: %1, IP: %2</translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="82"/>
        <source>Bad Http request, closing socket. IP: %1</source>
        <translation>Dårlig Http-anmodning, lukker sokkel. IP: %1</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation>Liste over hvidlistede IP-undernet</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Eksempel: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation>Tilføj undernet</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>Slet</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>The entered subnet is invalid.</source>
        <translation>Det indtastede undernet er ugyldigt.</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="50"/>
        <source>Copy</source>
        <translation>Kopiér</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="51"/>
        <source>Clear</source>
        <translation>Ryd</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Rediger</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Værktøjer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Filer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>&amp;Hjælp</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Når downloads er &amp;færdige</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>&amp;Vis</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>&amp;Indstillinger...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>&amp;Genoptag</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>Torrent&amp;opretter</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>Set Upload Limit...</source>
        <translation>Sæt grænse for upload...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Download Limit...</source>
        <translation>Sæt grænse for download...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Set Global Download Limit...</source>
        <translation>Sæt global grænse for download...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="248"/>
        <source>Set Global Upload Limit...</source>
        <translation>Sæt global grænse for upload...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="300"/>
        <location filename="../gui/mainwindow.ui" line="303"/>
        <source>Alternative Speed Limits</source>
        <translation>Alternative grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="311"/>
        <source>&amp;Top Toolbar</source>
        <translation>&amp;Øverste værktøjslinje</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="314"/>
        <source>Display Top Toolbar</source>
        <translation>Vis øverste værktøjslinje</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="322"/>
        <source>Status &amp;Bar</source>
        <translation>Status&amp;linje</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="330"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Hastighed i titellinjen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="333"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Vis overførselshastighed i titellinjen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="341"/>
        <source>&amp;RSS Reader</source>
        <translation>&amp;RSS-læser</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="349"/>
        <source>Search &amp;Engine</source>
        <translation>Søge&amp;motor</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="354"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>L&amp;ås qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="365"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;nér!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="484"/>
        <source>Close Window</source>
        <translation>Luk vindue</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>G&amp;enoptag alle</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="436"/>
        <source>Manage Cookies...</source>
        <translation>Håndter cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="439"/>
        <source>Manage stored network cookies</source>
        <translation>Håndter opbevarede netværkscookies</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="455"/>
        <source>Normal Messages</source>
        <translation>Normale meddelelser</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="463"/>
        <source>Information Messages</source>
        <translation>Informationsmeddelelser</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="471"/>
        <source>Warning Messages</source>
        <translation>Advarselsmeddelelser</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="479"/>
        <source>Critical Messages</source>
        <translation>Kritiske meddelelser</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="253"/>
        <source>Bottom of Queue</source>
        <translation>Nederst i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="256"/>
        <source>Move to the bottom of the queue</source>
        <translation>Flyt nederst i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="264"/>
        <source>Top of Queue</source>
        <translation>Øverst i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="267"/>
        <source>Move to the top of the queue</source>
        <translation>Flyt øverst i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="275"/>
        <source>Move Down Queue</source>
        <translation>Flyt ned i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="278"/>
        <source>Move down in the queue</source>
        <translation>Flyt ned i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="286"/>
        <source>Move Up Queue</source>
        <translation>Flyt op i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="289"/>
        <source>Move up in the queue</source>
        <translation>Flyt op i køen</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="376"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Afslut qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="384"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspendér systemet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="392"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Dvaletilstand</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="400"/>
        <source>S&amp;hutdown System</source>
        <translation>&amp;Luk ned</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="408"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Deaktiveret</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="423"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Statistik</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="428"/>
        <source>Check for Updates</source>
        <translation>Søg efter opdateringer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="431"/>
        <source>Check for Program Updates</source>
        <translation>Søg efter programopdateringer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>&amp;Om</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>Sæt på &amp;pause</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>&amp;Slet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>Sæt alle på p&amp;ause</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Tilføj torrent-fil...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>Åbn</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>&amp;Afslut</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>Åbn URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentation</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="357"/>
        <source>Lock</source>
        <translation>Lås</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="413"/>
        <location filename="../gui/mainwindow.ui" line="447"/>
        <location filename="../gui/mainwindow.cpp" line="1650"/>
        <source>Show</source>
        <translation>Vis</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1836"/>
        <source>Check for program updates</source>
        <translation>Søg efter programopdateringer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Tilføj torrent-&amp;link...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="368"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Hvis du kan lide qBittorrent, så donér venligst!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1871"/>
        <location filename="../gui/mainwindow.cpp" line="1873"/>
        <source>Execution Log</source>
        <translation>Eksekveringslog</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="638"/>
        <source>Clear the password</source>
        <translation>Ryd adgangskoden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="219"/>
        <source>Filter torrent list...</source>
        <translation>Filtrer torrentliste...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="191"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Set adgangskode</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="159"/>
        <source>Preferences</source>
        <translation>Præferencer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="193"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Ryd adgangskode</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="245"/>
        <source>Transfers</source>
        <translation>Overførsler</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="409"/>
        <location filename="../gui/mainwindow.cpp" line="1229"/>
        <source>qBittorrent is minimized to tray</source>
        <translation>qBittorrent er minimeret til bakke</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="409"/>
        <location filename="../gui/mainwindow.cpp" line="1140"/>
        <location filename="../gui/mainwindow.cpp" line="1229"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation>Opførslen kan ændres i indstillingerne. Du bliver ikke mindet om det igen.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="449"/>
        <source>Torrent file association</source>
        <translation>Filtilknytning for torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="450"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent er ikke standardprogrammet til åbning af torrent-filer eller magnet-links.
Vil du tilknytte qBittorrent til torrent-filer og magnet-links?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="533"/>
        <source>Icons Only</source>
        <translation>Kun ikoner</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="535"/>
        <source>Text Only</source>
        <translation>Kun tekst</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="537"/>
        <source>Text Alongside Icons</source>
        <translation>Tekst ved siden af ikoner</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="539"/>
        <source>Text Under Icons</source>
        <translation>Tekst under ikoner</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="541"/>
        <source>Follow System Style</source>
        <translation>Følg systemets stil</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="622"/>
        <location filename="../gui/mainwindow.cpp" line="1032"/>
        <source>UI lock password</source>
        <translation>Brugerfladens låseadgangskode</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="623"/>
        <location filename="../gui/mainwindow.cpp" line="1033"/>
        <source>Please type the UI lock password:</source>
        <translation>Skriv venligst brugerfladens låseadgangskode:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="628"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Adgangskoden skal indeholde mindst 3 tegn</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="639"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Er du sikker på, at du vil rydde adgangskoden?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="694"/>
        <source>Use regular expressions</source>
        <translation>Brug regulære udtryk</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="714"/>
        <source>Search</source>
        <translation>Søg</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="730"/>
        <source>Transfers (%1)</source>
        <translation>Overførsler (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="823"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="823"/>
        <source>Failed to add torrent: %1</source>
        <translation>Kunne ikke tilføje torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="830"/>
        <source>Torrent added</source>
        <translation>Torrent tilføjet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="830"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; blev tilføjet.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="836"/>
        <source>Download completion</source>
        <translation>Download er færdig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="842"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>I/O-fejl</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="933"/>
        <source>Recursive download confirmation</source>
        <translation>Bekræftelse for rekursiv download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="939"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="940"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="941"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="966"/>
        <source>Global Upload Speed Limit</source>
        <translation>Global grænse for uploadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="981"/>
        <source>Global Download Speed Limit</source>
        <translation>Global grænse for downloadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1054"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>qBittorrent er lige blevet opdateret og skal genstartes før ændringerne træder i kraft.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1140"/>
        <source>qBittorrent is closed to tray</source>
        <translation>qBittorrent er lukket til bakke</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1153"/>
        <source>Some files are currently transferring.</source>
        <translation>Nogle filer er ved at blive overført.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1153"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Er du sikker på, at du vil afslutte qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1155"/>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1156"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1157"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Altid ja</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1520"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1758"/>
        <location filename="../gui/mainwindow.cpp" line="1764"/>
        <source>Missing Python Runtime</source>
        <translation>Manglende Python-runtime</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1783"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>Din Python-version (%1) er forældet. Opgrader venligst til seneste version så søgemotorerne kan virke.
Minimumskrav: 2.7.9/3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1818"/>
        <source>qBittorrent Update Available</source>
        <translation>Der findes en opdatering til qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1830"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Bruger allerede den seneste qBittorrent-version</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="836"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; er færdig med at downloade.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="843"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>En I/O-fejl er opstået for torrenten &apos;%1&apos;.
 Årsag: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="934"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>Torrenten &apos;%1&apos; indeholder torrent-filer, vil du fortsætte deres download?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="956"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Kunne ikke downloade filen fra URL&apos;en &apos;%1&apos;, årsag: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1759"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python kræves for at bruge søgemotoren, men lader ikke til at være installeret.
Vil du installere den nu?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1765"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Python kræves for at bruge søgemotoren, men lader ikke til at være installeret.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1776"/>
        <location filename="../gui/mainwindow.cpp" line="1782"/>
        <source>Old Python Runtime</source>
        <translation>Gammel Python-runtime</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1777"/>
        <source>Your Python version (%1) is outdated. Minimum requirement: 2.7.9 / 3.3.0.
Do you want to install a newer version now?</source>
        <translation>Din Python-version (%1) er forældet. Minimumskrav: 2.7.9/3.3.0.
Vil du installere en nyere version nu?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1819"/>
        <source>A new version is available.</source>
        <translation>Der findes en ny version.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1820"/>
        <source>Do you want to download %1?</source>
        <translation>Vil du downloade %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1821"/>
        <source>Open changelog...</source>
        <translation>Åbn ændringslog...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1831"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Der findes ingen opdateringer.
Du bruger allerede den seneste version.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1835"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Søg efter opdateringer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1998"/>
        <source>Checking for Updates...</source>
        <translation>Søger efter opdateringer...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1999"/>
        <source>Already checking for program updates in the background</source>
        <translation>Søger allerede efter programopdateringer i baggrunden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2028"/>
        <source>Download error</source>
        <translation>Fejl ved download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2029"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python-opsætning kunne ikke downloades, årsag: %1.
Installer den venligst manuelt.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="628"/>
        <location filename="../gui/mainwindow.cpp" line="1040"/>
        <source>Invalid password</source>
        <translation>Ugyldig adgangskode</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="663"/>
        <location filename="../gui/mainwindow.cpp" line="674"/>
        <location filename="../gui/mainwindow.cpp" line="676"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="955"/>
        <source>URL download error</source>
        <translation>Fejl ved URL-download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1040"/>
        <source>The password is invalid</source>
        <translation>Adgangskoden er ugyldig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1539"/>
        <location filename="../gui/mainwindow.cpp" line="1544"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Downloadhastighed: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1540"/>
        <location filename="../gui/mainwindow.cpp" line="1545"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Uploadhastighed: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1552"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1/s, U: %2/s] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1650"/>
        <source>Hide</source>
        <translation>Skjul</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1151"/>
        <source>Exiting qBittorrent</source>
        <translation>Afslutter qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1355"/>
        <source>Open Torrent Files</source>
        <translation>Åbn torrent-filer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1356"/>
        <source>Torrent Files</source>
        <translation>Torrent-filer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1407"/>
        <source>Options were saved successfully.</source>
        <translation>Indstillinger blev gemt.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="175"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>Din dynamiske DNS blev opdateret.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="180"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Fejl med dynamisk DNS: Tjenesten er midlertidig utilgængelig, der prøves igen om 30 minutter.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="190"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Fejl med dynamisk DNS: angivne værtsnavn findes ikke på denne konto.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="196"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Fejl med dynamisk DNS: Ugyldig brugernavn/adgangskode.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="202"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Fejl med dynamisk DNS: qBittorrent blev sortlistet af tjenesten. Rapportér venligst en fejl på http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Fejl med dynamisk DNS: %1 blev returneret af tjenesten. Rapportér venligst en fejl på http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="216"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Fejl med dynamisk DNS: Dit brugernavn blev blokeret pga. misbrug.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="236"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Fejl med dynamisk DNS: angivne domænenavn er ugyldigt.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="247"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Fejl med dynamisk DNS: angivne brugernavn er for kort.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="258"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Fejl med dynamisk DNS: angivne adgangskode er for kort.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadManager</name>
    <message>
        <location filename="../base/net/downloadmanager.cpp" line="289"/>
        <source>Ignoring SSL error, URL: &quot;%1&quot;, errors: &quot;%2&quot;</source>
        <translation>Ignorerer SSL-fejl, URL: &quot;%1&quot;, fejl: &quot;%2&quot;</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="102"/>
        <location filename="../base/net/geoipmanager.cpp" line="429"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>GeoIP-database indlæst. Type: %1. Byggetidspunkt: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="106"/>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>Kunne ikke indlæse GeoIP-database. Årsag: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela, Bolivariske Republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>N/A</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="137"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="138"/>
        <source>United Arab Emirates</source>
        <translation>Forenede Arabiske Emirater</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="139"/>
        <source>Afghanistan</source>
        <translation>Afghanistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="140"/>
        <source>Antigua and Barbuda</source>
        <translation>Antigua og Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="141"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="142"/>
        <source>Albania</source>
        <translation>Albanien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="143"/>
        <source>Armenia</source>
        <translation>Armenien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>Antarctica</source>
        <translation>Antarktis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>American Samoa</source>
        <translation>Amerikansk Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Austria</source>
        <translation>Østrig</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Australia</source>
        <translation>Australien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Azerbaijan</source>
        <translation>Aserbajdsjan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bosnien-Hercegovina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Belgium</source>
        <translation>Belgien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Burkina Faso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Bulgaria</source>
        <translation>Bulgarien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Brazil</source>
        <translation>Brasilien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bouvet Island</source>
        <translation>Bouvetøen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Belarus</source>
        <translation>Hviderusland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Canada</source>
        <translation>Canada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Cocosøerne (Keelingøerne)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Den Demokratiske Republik Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Central African Republic</source>
        <translation>Centralafrikanske Republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Switzerland</source>
        <translation>Schweiz</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Cook Islands</source>
        <translation>Cookøerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Cameroon</source>
        <translation>Cameroun</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>China</source>
        <translation>Kina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Colombia</source>
        <translation>Colombia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cape Verde</source>
        <translation>Kap Verde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Curacao</source>
        <translation>Curacao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Christmas Island</source>
        <translation>Juleøen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>Cyprus</source>
        <translation>Cypern</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Czech Republic</source>
        <translation>Tjekkiet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Germany</source>
        <translation>Tyskland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Denmark</source>
        <translation>Danmark</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Dominican Republic</source>
        <translation>Dominikanske republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Algeria</source>
        <translation>Algeriet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Estonia</source>
        <translation>Estland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Egypt</source>
        <translation>Egypten</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Western Sahara</source>
        <translation>Vestsahara</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Spain</source>
        <translation>Spanien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Ethiopia</source>
        <translation>Etiopien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Finland</source>
        <translation>Finland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Falklandsøerne (Malvinas)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Micronesia, Federated States of</source>
        <translation>Mikronesiske Stater</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Faroe Islands</source>
        <translation>Færøerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>France</source>
        <translation>Frankrig</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>United Kingdom</source>
        <translation>England</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Grenada</source>
        <translation>Grenada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Georgia</source>
        <translation>Georgien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>French Guiana</source>
        <translation>Fransk Guiana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>Greenland</source>
        <translation>Grønland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>Guadeloupe</source>
        <translation>Guadeloupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Equatorial Guinea</source>
        <translation>Ækvatorial Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Greece</source>
        <translation>Grækenland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>South Georgia og De Sydlige Sandwichøer</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guinea-Bissau</source>
        <translation>Guinea-Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Heard- og McDonald-øerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Croatia</source>
        <translation>Kroatien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Hungary</source>
        <translation>Ungarn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Indonesia</source>
        <translation>Indonesien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Ireland</source>
        <translation>Irland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>India</source>
        <translation>Indien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>British Indian Ocean Territory</source>
        <translation>Det britiske territoriet i Det Indiske Ocean</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Iran, Den Islamiske Republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Iceland</source>
        <translation>Island</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Italy</source>
        <translation>Italien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>Jordan</source>
        <translation>Jordan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Japan</source>
        <translation>Japan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Kyrgyzstan</source>
        <translation>Kirgisistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Cambodia</source>
        <translation>Cambodia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Comoros</source>
        <translation>Comorerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Saint Kitts and Nevis</source>
        <translation>Saint Kitts og Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Korea, Demokratiske Folkerepublik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Korea, Republic of</source>
        <translation>Korea, Republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Cayman Islands</source>
        <translation>Caymanøerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos Demokratiske Folkerepublik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Lebanon</source>
        <translation>Lebanon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Saint Lucia</source>
        <translation>Saint Lucia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lithuania</source>
        <translation>Litauen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Luxembourg</source>
        <translation>Luxembourg</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Latvia</source>
        <translation>Letland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Morocco</source>
        <translation>Morocco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Monaco</source>
        <translation>Monaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Moldova, Republic of</source>
        <translation>Moldova, Republikken</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Marshall Islands</source>
        <translation>Marshalløerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Mongolia</source>
        <translation>Mongoliet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Northern Mariana Islands</source>
        <translation>Nordmarianerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Martinique</source>
        <translation>Martinique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Mauritania</source>
        <translation>Mauretanien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mauritius</source>
        <translation>Mauritius</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Maldives</source>
        <translation>Maldiverne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Mexico</source>
        <translation>Mexico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Malaysia</source>
        <translation>Malaysia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Mozambique</source>
        <translation>Mozambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>New Caledonia</source>
        <translation>Ny Kaledonien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Norfolk Island</source>
        <translation>Norfolk Island</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Netherlands</source>
        <translation>Holland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Norway</source>
        <translation>Norge</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>New Zealand</source>
        <translation>New Zealand</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>French Polynesia</source>
        <translation>Fransk Polynesien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Papua New Guinea</source>
        <translation>Papua Ny Guinea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Philippines</source>
        <translation>Filippinerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Poland</source>
        <translation>Polen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>Saint Pierre og Miquelon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Reunion</source>
        <translation>Genforening</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Romania</source>
        <translation>Rumænien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Russian Federation</source>
        <translation>Den Russiske Føderation</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Saudi Arabia</source>
        <translation>Saudi Arabien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Solomon Islands</source>
        <translation>Salomonøerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Seychelles</source>
        <translation>Seychellerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Sudan</source>
        <translation>Sudan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Sweden</source>
        <translation>Sverige</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Singapore</source>
        <translation>Singapore</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Slovenia</source>
        <translation>Slovenien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard og Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Slovakia</source>
        <translation>Slovakiet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sierra Leone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Suriname</source>
        <translation>Surinam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Sao Tome and Principe</source>
        <translation>Sao Tome og Principe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Syrian Arab Republic</source>
        <translation>Syriske Arabiske Republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Swaziland</source>
        <translation>Swaziland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Turks and Caicos Islands</source>
        <translation>Turks- og Caicosøerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>Chad</source>
        <translation>Chad</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>French Southern Territories</source>
        <translation>Franske Sydlige Territorier</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Thailand</source>
        <translation>Thailand</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Tajikistan</source>
        <translation>Tadsjikistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>Tunisia</source>
        <translation>Tunesien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Vietnam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="418"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation>Kunne ikke udpakke GeoIP-databasefil.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Timor-Leste</source>
        <translation>Timor-Leste</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolivia, Flernationale Stat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire , Sint Eustatius og Saba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Cote d&apos;Ivoire</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Libya</source>
        <translation>Libyen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Saint Martin (French part)</source>
        <translation>Saint Martin (fransk del)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Makedonien, Den Tidligere Jugoslaviske Republik</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Pitcairn</source>
        <translation>Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Palestine, State of</source>
        <translation>Palæstina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Saint Helena , Ascension og Tristan da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>South Sudan</source>
        <translation>Sydsudan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sint Maarten (hollandske del)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Turkey</source>
        <translation>Tyrkiet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad og Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzania</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Ukraine</source>
        <translation>Ukraine</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Mindre Amerikanske Oversøiske Øer</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>United States</source>
        <translation>Forenede stater</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Pavestolen (Vatikanstaten)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>Saint Vincent og Grenadinerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>Virgin Islands, British</source>
        <translation>Jomfruøerne, britiske</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Virgin Islands, U.S.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis og Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Yemen</source>
        <translation>Yemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Serbia</source>
        <translation>Serbien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>South Africa</source>
        <translation>Sydafrika</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Zambia</source>
        <translation>Zambia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Aland Islands</source>
        <translation>Ålandsøerne</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Isle of Man</source>
        <translation>Isle of Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Saint Barthelemy</source>
        <translation>Saint Barthelemy</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="438"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>Kunne ikke gemme downloadet GeoIP-databasefil.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="440"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>GeoIP-databasen blev opdateret.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="411"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>Kunne ikke downloade GeoIP-databasefilen. Årsag: %1</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="509"/>
        <source>Email Notification Error:</source>
        <translation>Fejl ved underretning via e-mail:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>Opførsel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>Forbindelse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>Hastighed</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>Webgrænseflade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avanceret</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="167"/>
        <location filename="../gui/optionsdialog.ui" line="205"/>
        <source>(Requires restart)</source>
        <translation>(kræver genstart)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="218"/>
        <source>Transfer List</source>
        <translation>Overførselsliste</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="224"/>
        <source>Confirm when deleting torrents</source>
        <translation>Bekræft ved sletning af torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="234"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Brug alternative farver for rækker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="246"/>
        <source>Hide zero and infinity values</source>
        <translation>Skjul nul og uendelige værdier</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="254"/>
        <source>Always</source>
        <translation>Altid</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="259"/>
        <source>Paused torrents only</source>
        <translation>Kun torrents som er sat på pause</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="282"/>
        <source>Action on double-click</source>
        <translation>Handling ved dobbeltklik</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="288"/>
        <source>Downloading torrents:</source>
        <translation>Downloader torrents:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="299"/>
        <location filename="../gui/optionsdialog.ui" line="325"/>
        <source>Start / Stop Torrent</source>
        <translation>Start/stop torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="304"/>
        <location filename="../gui/optionsdialog.ui" line="330"/>
        <source>Open destination folder</source>
        <translation>Åbn destinationsmappe</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="309"/>
        <location filename="../gui/optionsdialog.ui" line="340"/>
        <source>No action</source>
        <translation>Ingen handling</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="317"/>
        <source>Completed torrents:</source>
        <translation>Færdige torrents:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="367"/>
        <source>Desktop</source>
        <translation>Skrivebord</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="373"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Start qBittorrent når Windows starter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="380"/>
        <source>Show splash screen on start up</source>
        <translation>Vis splash-skærm ved opstart</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="390"/>
        <source>Start qBittorrent minimized</source>
        <translation>Start qBittorrent minimeret</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="397"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Bekræftelse ved afslutning når der er aktive torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="407"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Bekræftelse ved automatisk afslutning når downloads er færdige</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="586"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1160"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>&amp;Underretning via e-mail når download er færdig</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1255"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Kør &amp;eksternt program når torrent er færdig</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1711"/>
        <source>IP Fi&amp;ltering</source>
        <translation>IP-fi&amp;ltrering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1911"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Planlæg brugen af &amp;alternative grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1923"/>
        <source>From:</source>
        <comment>From start time</comment>
        <translation>Fra:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1947"/>
        <source>To:</source>
        <comment>To end time</comment>
        <translation>Til:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2198"/>
        <source>Allow encryption</source>
        <translation>Tillad kryptering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2243"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Mere information&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2271"/>
        <source>&amp;Torrent Queueing</source>
        <translation>&amp;Torrent sat i kø</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2555"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>Tilføj &amp;automatisk disse trackere til nye downloads:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2628"/>
        <source>RSS Reader</source>
        <translation>RSS-læser</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2634"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Aktivér hentning af RSS-feeds</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2643"/>
        <source>Feeds refresh interval:</source>
        <translation>Interval for genopfriskning af feeds:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2660"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Maksimum antal artikler pr. feed:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2459"/>
        <location filename="../gui/optionsdialog.ui" line="2667"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2450"/>
        <source>Seeding Limits</source>
        <translation>Grænser for seeding</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2472"/>
        <source>When seeding time reaches</source>
        <translation>Når seedingtid når</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2493"/>
        <source>Pause torrent</source>
        <translation>Sæt torrent på pause</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2498"/>
        <source>Remove torrent</source>
        <translation>Fjern torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2503"/>
        <source>Remove torrent and its files</source>
        <translation>Fjern torrenten og dens filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2508"/>
        <source>Enable super seeding for torrent</source>
        <translation>Aktivér superseeding for torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2516"/>
        <source>When ratio reaches</source>
        <translation>Når deleforhold når</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2701"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Automatisk download af RSS-torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2707"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Aktivér automatisk download af RSS-torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2714"/>
        <source>Edit auto downloading rules...</source>
        <translation>Rediger regler for automatisk download...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2724"/>
        <source>RSS Smart Episode Filter</source>
        <translation>RSS smart episodefilter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2730"/>
        <source>Download REPACK/PROPER episodes</source>
        <translation>Download REPACK-/PROPER-episoder</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2737"/>
        <source>Filters:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2798"/>
        <source>Web User Interface (Remote control)</source>
        <translation>Webgrænseflade (fjernstyring)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2812"/>
        <source>IP address:</source>
        <translation>IP-adresse:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2819"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>IP-adresse som webgrænsefladen vil binde til.
Angiv en IPv4- eller IPv6-adresse. Du kan angive &quot;0.0.0.0&quot; til enhver IPv4-adresse,
&quot;::&quot; til enhver IPv6-adresse eller &quot;*&quot; til både IPv4 og IPv6.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2977"/>
        <source>Session timeout:</source>
        <translation>Sessiontimeout:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2984"/>
        <source>Disabled</source>
        <translation>Deaktiveret</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3071"/>
        <source>Server domains:</source>
        <translation>Serverdomæner:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3078"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>Hvidliste til filtrering af HTTP værtsheaderværdier.
For at afværge DNS-genbindingsangreb,
bør du putte domænenavne i som bruges af webgrænsefladens server.

Brug &apos;;&apos; til af adskille flere indtastninger. Jokertegnet &apos;*&apos; kan bruges.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2860"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>&amp;Brug HTTPS i stedet for HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2948"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation>Tilsidesæt godkendelse for klienter på localhost</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2955"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation>Tilsidesæt godkendelse for klienter i hvidlistede IP-undernet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2968"/>
        <source>IP subnet whitelist...</source>
        <translation>IP-undernet-hvidliste...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3097"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>Opdater mit &amp;dynamiske domænenavn</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="426"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimer qBittorrent til underretningsområdet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Interface</source>
        <translation>Grænseflade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="139"/>
        <source>Language:</source>
        <translation>Sprog:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="190"/>
        <source>Theme:</source>
        <translation>Tema:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="436"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Luk qBittorrent til underretningsområdet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="445"/>
        <source>Tray icon style:</source>
        <translation>Stil for bakkeikon:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="453"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="458"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monokrom (Mørkt tema)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="463"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monokrom (Lyst tema)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="489"/>
        <source>File association</source>
        <translation>Filtilknytning</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="495"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Brug qBittorrent til .torrent-filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="502"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Brug qBittorrent til magnet-links</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="512"/>
        <source>Check for program updates</source>
        <translation>Søg efter programopdateringer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="522"/>
        <source>Power Management</source>
        <translation>Strømstyring</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="565"/>
        <source>Save path:</source>
        <translation>Gemmesti:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="579"/>
        <source>Backup the log file after:</source>
        <translation>Sikkerhedskopiér logfilen efter:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="619"/>
        <source>Delete backup logs older than:</source>
        <translation>Slet sikkerhedskopieret logge som er ældre end:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="643"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>dage</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="648"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>måneder</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="653"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>år</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="727"/>
        <source>When adding a torrent</source>
        <translation>Når en torrent tilføjes</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="742"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Bring torrent-dialogen forrest</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="765"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Start ikke download automatisk</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="772"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>Skal .torrent-filen slettes efter den er blevet tilføjet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="787"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>Slet også .torrent-filer som fik deres tilføjelse annulleret</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="790"/>
        <source>Also when addition is cancelled</source>
        <translation>Også når tilføjelse annulleres</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="812"/>
        <source>Warning! Data loss possible!</source>
        <translation>Advarsel! Data kan gå tabt!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="848"/>
        <source>Saving Management</source>
        <translation>Gemmehåndtering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="856"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Standardtilstand for torrent-håndtering:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="868"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>Automatisk tilstand betyder at diverse torrent-egenskaber (f.eks. gemmesti) vil blive besluttet af den tilknyttede kategori</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="872"/>
        <source>Manual</source>
        <translation>Manuelt</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="877"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="900"/>
        <source>When Torrent Category changed:</source>
        <translation>Når torrentkategori ændres:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="910"/>
        <source>Relocate torrent</source>
        <translation>Flyt torrent til en anden placering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="915"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Skift torrent til manuel tilstand</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="938"/>
        <source>When Default Save Path changed:</source>
        <translation>Når standardgemmesti ændres:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="951"/>
        <location filename="../gui/optionsdialog.ui" line="992"/>
        <source>Relocate affected torrents</source>
        <translation>Flyt påvirkede torrents til en anden placering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="956"/>
        <location filename="../gui/optionsdialog.ui" line="997"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Skift påvirkede torrents til manuel tilstand</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1022"/>
        <source>Use Subcategories</source>
        <translation>Brug underkategorier</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1041"/>
        <source>Default Save Path:</source>
        <translation>Standardgemmesti:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1055"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Behold ufærdige torrents i:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1048"/>
        <source>Copy .torrent files to:</source>
        <translation>Kopiér .torrent-filer til:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="417"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Vis &amp;qBittorrent i underretningsområdet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="545"/>
        <source>&amp;Log file</source>
        <translation>&amp;Logfil</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="733"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Vis &amp;torrent-indhold og nogle valgmuligheder</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="755"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation>Opret undermappe til torrents med mere end én fil</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="775"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>&amp;Slet .torrent-filer bagefter </translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1034"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Kopiér færdige .torrent downloads til:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="827"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Præ-allokér alle filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="335"/>
        <source>Preview file, otherwise open destination folder</source>
        <translation>Forhåndsvis fil, ellers åbn distinationsmappe</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="528"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation>Forhindr systemet i at gå i dvale når der downloades torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="535"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation>Forhindr systemet i at gå i dvale når der seedes torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="834"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Tilføj .!qB-endelse til slutningen af ufærdige filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="841"/>
        <source>Enable recursive download dialog</source>
        <translation>Aktivér rekursiv download-dialog</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="979"/>
        <source>When Category Save Path changed:</source>
        <translation>Når kategoriens gemmesti ændres:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1076"/>
        <source>Automatically add torrents from:</source>
        <translation>Tilføj automatisk torrents fra:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1123"/>
        <source>Add entry</source>
        <translation>Tilføj element</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1133"/>
        <source>Remove entry</source>
        <translation>Fjern element</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1177"/>
        <source>To:</source>
        <comment>To receiver</comment>
        <translation>Til:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1184"/>
        <source>SMTP server:</source>
        <translation>SMTP-server:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1197"/>
        <source>From:</source>
        <comment>From sender</comment>
        <translation>Fra:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1206"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Denne server kræver en sikker forbindelse (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1213"/>
        <location filename="../gui/optionsdialog.ui" line="2911"/>
        <source>Authentication</source>
        <translation>Godkendelse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1225"/>
        <location filename="../gui/optionsdialog.ui" line="1672"/>
        <location filename="../gui/optionsdialog.ui" line="2919"/>
        <location filename="../gui/optionsdialog.ui" line="3155"/>
        <source>Username:</source>
        <translation>Brugernavn:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1235"/>
        <location filename="../gui/optionsdialog.ui" line="1682"/>
        <location filename="../gui/optionsdialog.ui" line="2929"/>
        <location filename="../gui/optionsdialog.ui" line="3169"/>
        <source>Password:</source>
        <translation>Adgangskode:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1317"/>
        <source>Enabled protocol:</source>
        <translation>Aktiveret protokol:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1325"/>
        <source>TCP and μTP</source>
        <translation>TCP og μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1358"/>
        <source>Listening Port</source>
        <translation>Lyttende port</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1366"/>
        <source>Port used for incoming connections:</source>
        <translation>Port der bruges til indgående forbindelser:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1386"/>
        <source>Random</source>
        <translation>Tilfældig</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1408"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Brug UPnP/NAT-PMP port-viderestilling fra min router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1418"/>
        <source>Use different port on each startup</source>
        <translation>Brug en anden port ved hver opstart</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1428"/>
        <source>Connections Limits</source>
        <translation>Grænser for forbindelser</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1444"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Maksimum antal forbindelser pr. torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1454"/>
        <source>Global maximum number of connections:</source>
        <translation>Global maksimum antal forbindelser:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1493"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Maksimum antal uploadpladser pr. torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1503"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Global maksimum antal uploadpladser:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1542"/>
        <source>Proxy Server</source>
        <translation>Proxyserver</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1550"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1558"/>
        <source>(None)</source>
        <translation>(Ingen)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1563"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1568"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1573"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1584"/>
        <source>Host:</source>
        <translation>Vært:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1604"/>
        <location filename="../gui/optionsdialog.ui" line="2828"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1632"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Ellers bruges proxyserveren kun til tracker-forbindelser</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1635"/>
        <source>Use proxy for peer connections</source>
        <translation>Brug proxy til modpartsforbindelser</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1642"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>RSS-feeds, søgemotor softwareopdateringer og alt andet end torrent-overførsler og relaterede handlinger (såsom modpartsudvekslinger) vil bruge en direkte forbindelse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1645"/>
        <source>Use proxy only for torrents</source>
        <translation>Brug kun proxy til torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1658"/>
        <source>A&amp;uthentication</source>
        <translation>&amp;Godkendelse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1698"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: Adgangskoden gemmes ukrypteret</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1719"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Filtrer sti (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1735"/>
        <source>Reload the filter</source>
        <translation>Genindlæs filteret</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1750"/>
        <source>Manually banned IP addresses...</source>
        <translation>Manuelt udelukkede IP-adresser...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1757"/>
        <source>Apply to trackers</source>
        <translation>Anvend på trackere</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1815"/>
        <source>Global Rate Limits</source>
        <translation>Globale grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1821"/>
        <location filename="../gui/optionsdialog.ui" line="1837"/>
        <location filename="../gui/optionsdialog.ui" line="1892"/>
        <location filename="../gui/optionsdialog.ui" line="2022"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1824"/>
        <location filename="../gui/optionsdialog.ui" line="1840"/>
        <location filename="../gui/optionsdialog.ui" line="1895"/>
        <location filename="../gui/optionsdialog.ui" line="2025"/>
        <location filename="../gui/optionsdialog.ui" line="2368"/>
        <location filename="../gui/optionsdialog.ui" line="2381"/>
        <source> KiB/s</source>
        <translation> KiB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1869"/>
        <location filename="../gui/optionsdialog.ui" line="2051"/>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1876"/>
        <location filename="../gui/optionsdialog.ui" line="2058"/>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1886"/>
        <source>Alternative Rate Limits</source>
        <translation>Alternative grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1974"/>
        <source>When:</source>
        <translation>Når:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1988"/>
        <source>Every day</source>
        <translation>Hver dag</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1993"/>
        <source>Weekdays</source>
        <translation>Hverdage</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1998"/>
        <source>Weekends</source>
        <translation>Weekender</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2068"/>
        <source>Rate Limits Settings</source>
        <translation>Indstillinger for grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2088"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Anvend grænse for hastighed til modparter på LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2081"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Anvend grænse for hastighed til transport-overhead</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2074"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Anvend grænse for hastighed til µTP-protokol</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2146"/>
        <source>Privacy</source>
        <translation>Privatliv</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2152"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Aktivér DHT (decentraliseret netværk) for at finde flere modparter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2162"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Udveksel modparter med kompatible Bittorrent-klienter (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2165"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Aktivér modpartsudveksling (PeX) for at finde flere modparter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2175"/>
        <source>Look for peers on your local network</source>
        <translation>Søg efter modparter på dit lokale netværk</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2178"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Aktivér lokal modpartsopdagelse for at finde flere modparter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2190"/>
        <source>Encryption mode:</source>
        <translation>Krypteringstilstand:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2203"/>
        <source>Require encryption</source>
        <translation>Kræv kryptering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2208"/>
        <source>Disable encryption</source>
        <translation>Deaktivér kryptering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2233"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Aktivér når der bruges en proxy eller en VPN-forbindelse</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2236"/>
        <source>Enable anonymous mode</source>
        <translation>Aktivér anonym tilstand</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2283"/>
        <source>Maximum active downloads:</source>
        <translation>Maksimum aktive downloads:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2303"/>
        <source>Maximum active uploads:</source>
        <translation>Maksimum aktive uploads:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2323"/>
        <source>Maximum active torrents:</source>
        <translation>Maksimum aktive torrents:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2356"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Tæl ikke langsomme torrents med i disse grænser</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2394"/>
        <source>Upload rate threshold:</source>
        <translation>Grænse for uploadhastighed:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2401"/>
        <source>Download rate threshold:</source>
        <translation>Grænse for downloadhastighed:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2421"/>
        <location filename="../gui/optionsdialog.ui" line="2987"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation>sek.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2437"/>
        <source>Torrent inactivity timer:</source>
        <translation>Timer for torrent inaktivitet:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2479"/>
        <source>then</source>
        <translation>og så</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2850"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Brug UPnP/NAT-PMP til at viderestille porten fra min router</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2879"/>
        <source>Certificate:</source>
        <translation>Certifikat:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2872"/>
        <source>Key:</source>
        <translation>Nøgle:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2892"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information om certifikater&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2939"/>
        <source>Change current password</source>
        <translation>Skift nuværende adgangskode</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3015"/>
        <source>Use alternative Web UI</source>
        <translation>Brug alternativ webgrænseflade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3027"/>
        <source>Files location:</source>
        <translation>Filplacering:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3040"/>
        <source>Security</source>
        <translation>Sikkerhed</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3046"/>
        <source>Enable clickjacking protection</source>
        <translation>Aktivér beskyttelse mod klikkidnapning</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3053"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation>Aktivér beskyttelse mod Cross-Site Request Forgery (CSRF)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3060"/>
        <source>Enable Host header validation</source>
        <translation>Aktivér validering af værtsheader</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3109"/>
        <source>Service:</source>
        <translation>Tjeneste:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3132"/>
        <source>Register</source>
        <translation>Registrer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3141"/>
        <source>Domain name:</source>
        <translation>Domænenavn:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="145"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Ved at aktivere disse valgmuligheder kan du &lt;strong&gt;uigenkaldeligt miste&lt;/strong&gt; dine .torrent-filer!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="147"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Når disse valgmuligheder er aktiveret, så vil qBittorent &lt;strong&gt;slette&lt;/strong&gt; .torrent-filer efter det lykkedes at tilføje dem (den første valgmulighed) eller ej (den anden valgmulighed) til sin downloadkø. Dette vil &lt;strong&gt;ikke kun&lt;/strong&gt; blive anvendt på filerne som er åbnet via menuhandlingen &amp;ldquo;Tilføj torrent&amp;rdquo; men også til dem der er blevet åbnet via &lt;strong&gt;filtypetilknytning&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="152"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Hvis du aktiverer den anden valgmulighed (&amp;ldquo;Også når tilføjelse annulleres&amp;rdquo;), &lt;strong&gt;så slettes .torrent-filen&lt;/strong&gt;, selv hvis du trykker på &amp;ldquo;&lt;strong&gt;Annuller&lt;/strong&gt;&amp;rdquo; i &amp;ldquo;Tilføj torrent&amp;rdquo;-dialogen</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="207"/>
        <source>Choose Alternative UI files location</source>
        <translation>Vælg alternativ placering til brugefladefiler</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="300"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Understøttede parametre (forskel på store og små bogstaver):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="301"/>
        <source>%N: Torrent name</source>
        <translation>%N: Torrentnavn</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="302"/>
        <source>%L: Category</source>
        <translation>%L: Kategori</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="304"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Indholdssti (samme som rodsti til torrent med flere filer)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="305"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Rodsti (første torrent-undermappesti)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="306"/>
        <source>%D: Save path</source>
        <translation>%D: Gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="307"/>
        <source>%C: Number of files</source>
        <translation>%C: Antal filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="308"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrentstørrelse (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="309"/>
        <source>%T: Current tracker</source>
        <translation>%T: Nuværende tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="310"/>
        <source>%I: Info hash</source>
        <translation>%I: Infohash</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="311"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Tip: Omslut parameter med citationstegn så teksten ikke bliver afkortet af blanktegn (f.eks. &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="379"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation>En torrent betrages som værende langsom hvis dens download- og uploadhastighed forbliver under disse værdier for &quot;Timer for torrent inaktivitet&quot; sekunder</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="388"/>
        <source>Certificate</source>
        <translation>Certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="389"/>
        <source>Select certificate</source>
        <translation>Vælg certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="391"/>
        <source>Private key</source>
        <translation>Privat nøgle</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="392"/>
        <source>Select private key</source>
        <translation>Vælg privat nøgle</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="501"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="506"/>
        <source>Select...</source>
        <translation>Vælg...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="514"/>
        <source>Select qBittorrent theme file</source>
        <translation>Vælg qBittorrent-temafil</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="514"/>
        <source>qBittorrent Theme File (*.qbtheme)</source>
        <translation>qBittorrent-temafil (*.qbtheme)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1537"/>
        <source>Select folder to monitor</source>
        <translation>Vælg mappe som skal overvåges</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1544"/>
        <source>Folder is already being monitored:</source>
        <translation>Mappen overvåges allerede:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1547"/>
        <source>Folder does not exist:</source>
        <translation>Mappen findes ikke:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1550"/>
        <source>Folder is not readable:</source>
        <translation>Mappen kan ikke læses:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1561"/>
        <source>Adding entry failed</source>
        <translation>Tilføjelse af element mislykkedes</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1629"/>
        <location filename="../gui/optionsdialog.cpp" line="1653"/>
        <source>Invalid path</source>
        <translation>Ugyldig sti</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1800"/>
        <source>Location Error</source>
        <translation>Fejl ved placering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1800"/>
        <source>The alternative Web UI files location cannot be blank.</source>
        <translation>Placeringen til de alternative webbrugefladefiler må ikke være tom.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="448"/>
        <location filename="../gui/optionsdialog.cpp" line="451"/>
        <location filename="../gui/optionsdialog.cpp" line="1589"/>
        <location filename="../gui/optionsdialog.cpp" line="1591"/>
        <source>Choose export directory</source>
        <translation>Vælg eksportmappe</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="303"/>
        <source>%G: Tags (separated by comma)</source>
        <translation>%G: Mærkatet (separeret af komma)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="445"/>
        <location filename="../gui/optionsdialog.cpp" line="458"/>
        <location filename="../gui/optionsdialog.cpp" line="461"/>
        <source>Choose a save directory</source>
        <translation>Vælg en gemmemappe</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="454"/>
        <source>Choose an IP filter file</source>
        <translation>Vælg en IP-filterfil</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="455"/>
        <source>All supported filters</source>
        <translation>Alle understøttede filtre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1693"/>
        <source>Parsing error</source>
        <translation>Fejl ved fortolkning</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1693"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Kunne ikke behandle det angivne IP-filter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1695"/>
        <source>Successfully refreshed</source>
        <translation>Genopfrisket</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1695"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Behandling af det angivne IP-filter lykkedes: %1 regler blev anvendt.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1659"/>
        <source>Invalid key</source>
        <translation>Ugyldig nøgle</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1659"/>
        <source>This is not a valid SSL key.</source>
        <translation>Dette er ikke en gyldig SSL-nøgle.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1635"/>
        <source>Invalid certificate</source>
        <translation>Ugyldigt certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="110"/>
        <source>Preferences</source>
        <translation>Præferencer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1635"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Dette er ikke et gyldigt SSL-certifikat.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1778"/>
        <source>Time Error</source>
        <translation>Fejl ved tid</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1778"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Start- og slut-tiden må ikke være det samme.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1787"/>
        <location filename="../gui/optionsdialog.cpp" line="1791"/>
        <source>Length Error</source>
        <translation>Fejl ved længde</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1787"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Webgrænsefladens brugernavn skal være mindst 3 tegn langt.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1791"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Webgrænsefladens adgangskode skal være mindst 6 tegn langt.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="271"/>
        <source>Interested(local) and Choked(peer)</source>
        <translation>Interested(local) og choked(peer)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="277"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interested(local) og unchoked(peer)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="286"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interested(peer) og choked(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="292"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interested(peer) og unchoked(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="299"/>
        <source>optimistic unchoke</source>
        <translation>optimistisk unchoke</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="305"/>
        <source>peer snubbed</source>
        <translation>modpart afbrudt</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="311"/>
        <source>incoming connection</source>
        <translation>indgående forbindelse</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="318"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>not interested(local) og unchoked(peer)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="325"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>not interested(peer) og unchoked(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="331"/>
        <source>peer from PEX</source>
        <translation>modpart fra PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="337"/>
        <source>peer from DHT</source>
        <translation>modpart fra DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="343"/>
        <source>encrypted traffic</source>
        <translation>krypteret trafik</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="349"/>
        <source>encrypted handshake</source>
        <translation>krypteret håndtryk</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="361"/>
        <source>peer from LSD</source>
        <translation>modpart fra LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Flags</source>
        <translation>Flag</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Connection</source>
        <translation>Forbindelse</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Forløb</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Downloadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Uploadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="84"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Downloadet</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="85"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Uploadet</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="86"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevans</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="87"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Filer</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="161"/>
        <source>Column visibility</source>
        <translation>Synlighed for kolonne</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="243"/>
        <source>Add a new peer...</source>
        <translation>Tilføj en ny modpart...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="252"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="254"/>
        <source>Adding peers</source>
        <translation>Tilføjer modparter</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="252"/>
        <source>Some peers cannot be added. Check the Log for details.</source>
        <translation>Nogle modparter kan ikke tilføjes. Tjek loggen for detaljer.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="254"/>
        <source>Peers are added to this torrent.</source>
        <translation>Der er tilføjet modparter til torrenten.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="264"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="277"/>
        <source>Ban peer permanently</source>
        <translation>Udeluk modpart permanent</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>Are you sure you want to permanently ban the selected peers?</source>
        <translation>Er du sikker på, at du vil udelukke de valgte modparter permanent?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="286"/>
        <source>Peer &quot;%1&quot; is manually banned</source>
        <translation>Modparten &quot;%1&quot; er blevet udelukket manuelt</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Country</source>
        <translation>Land</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <source>Copy IP:port</source>
        <translation>Kopiér IP:port</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Tilføj modparter</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>Liste over modparter som skal tilføjes (én IP pr. linje):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Format: IPv4:port/[IPv6]:port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="61"/>
        <source>No peer entered</source>
        <translation>Der er ikke indtastet nogen modpart</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="62"/>
        <source>Please type at least one peer.</source>
        <translation>Skriv venligst mindst én modpart.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="72"/>
        <source>Invalid peer</source>
        <translation>Ugyldig modpart</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="73"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>Modparten &apos;%1&apos; er ugyldig.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="161"/>
        <source>White: Unavailable pieces</source>
        <translation>Hvis: Utilgængelige stykker</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="162"/>
        <source>Blue: Available pieces</source>
        <translation>Blå: Tilgængelige stykker</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="265"/>
        <source>Files in this piece:</source>
        <translation>Filer i dette stykke:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="269"/>
        <source>File in this piece</source>
        <translation>Fil i dette stykke</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="271"/>
        <source>File in these pieces</source>
        <translation>Fil i disse stykker</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="290"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Vent med at se detaljeret information før metadata bliver tilgængelig</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="292"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Hold Skift-tasten nede for detaljeret information</translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Søge-plugins</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Installerede søge-plugins:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation>Aktiveret</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Advarsel: Sørg for at overholde dit lands love om ophavsret når du downloader torrents fra søgemotorerne.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Her kan du finde nye søgemotor-plugins: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Installer en ny</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Søg efter opdateringer</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation>Luk</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Afinstaller</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="157"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="222"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="282"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="161"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="203"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="226"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="286"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="209"/>
        <source>Uninstall warning</source>
        <translation>Advarsel om afinstallation</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="209"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Nogle  plugins kunne ikke afinstalleres da de er inkluderet i qBittorrent. Du kan kun afinstallere dem du selv har installeret
Pluginsne blev deaktiveret.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="211"/>
        <source>Uninstall success</source>
        <translation>Afinstallationen lykkedes</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="211"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Afinstallationen af alle valgte plugins lykkedes</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="468"/>
        <source>Search plugin update</source>
        <translation>Opdatering af søge-plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <source>Plugins installed or updated: %1</source>
        <translation>Plugins installeret eller opdateret: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="343"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="350"/>
        <source>New search engine plugin URL</source>
        <translation>Ny URL for søgemotor-plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="344"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="351"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>Invalid link</source>
        <translation>Ugyldigt link</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Linket ser ikke ud til at henvise til et søgemotor-plugin.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="364"/>
        <source>Select search plugins</source>
        <translation>Vælg søge-plugins</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="365"/>
        <source>qBittorrent search plugin</source>
        <translation>qBittorrent søge-plugins</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <source>All your plugins are already up to date.</source>
        <translation>Alle dine plugins er allerede af nyeste udgave.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>Beklager, kunne ikke søge efter opdateringer til plugin. %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="450"/>
        <source>Search plugin install</source>
        <translation>Installation af søge-plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="451"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>Kunne ikke installere &quot;%1&quot;-søgemotor-plugin. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="469"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>Kunne ikke opdatere &quot;%1&quot;-søgemotor-plugin. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Plugin-kilde</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Søg efter plugin-kilde:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation>Lokal fil</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation>Weblink</translation>
    </message>
</context>
<context>
    <name>PortForwarderImpl</name>
    <message>
        <location filename="../base/bittorrent/private/portforwarderimpl.cpp" line="103"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Understøttelse af UPnP/NAT-PMP [TIL]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/portforwarderimpl.cpp" line="113"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Understøttelse af UPnP/NAT-PMP [FRA]</translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="77"/>
        <source>qBittorrent is active</source>
        <translation>qBittorrent er aktiv</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="58"/>
        <source>The following files from torrent &quot;%1&quot; support previewing, please select one of them:</source>
        <translation>Følgende filer fra torrenten &quot;%1&quot; understøtter forhåndsvisning, vælg en af dem:</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="61"/>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="68"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="69"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="70"/>
        <source>Progress</source>
        <translation>Forløb</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="132"/>
        <source>Preview impossible</source>
        <translation>Forhåndsvisning ikke muligt</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="133"/>
        <source>Sorry, we can&apos;t preview this file: &quot;%1&quot;.</source>
        <translation>Beklager, vi kan ikke forhåndsvise filen: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Forhåndsvis valgte</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/private/fspathedit_p.cpp" line="308"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; findes ikke</translation>
    </message>
    <message>
        <location filename="../gui/private/fspathedit_p.cpp" line="310"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; henviser ikke til en mappe</translation>
    </message>
    <message>
        <location filename="../gui/private/fspathedit_p.cpp" line="312"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; henviser ikke til en fil</translation>
    </message>
    <message>
        <location filename="../gui/private/fspathedit_p.cpp" line="314"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>Har ikke læsetilladelse i &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/private/fspathedit_p.cpp" line="316"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>Har ikke skrivetilladelse i &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="121"/>
        <source>Not downloaded</source>
        <translation>Ikke downloadet</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="130"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="195"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="140"/>
        <source>N/A</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="194"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>Download ikke</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="124"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="196"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Høj</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="118"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Blandet</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="127"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="197"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Højeste</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="51"/>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="60"/>
        <source>Trackers</source>
        <translation>Trackere</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="69"/>
        <source>Peers</source>
        <translation>Modparter</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="78"/>
        <source>HTTP Sources</source>
        <translation>HTTP-kilder</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="87"/>
        <source>Content</source>
        <translation>Indhold</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="98"/>
        <source>Speed</source>
        <translation>Hastighed</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Downloadet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Tilgængelighed:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Forløb:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Overførsel</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tid aktiv:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>ETA:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Uploadet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Seeds:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Downloadhastighed:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Uploadhastighed:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Modparter:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Downloadgrænse:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Uploadgrænse:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Spildt:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Forbindelser:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1023"/>
        <source>Select All</source>
        <translation>Vælg alt</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1030"/>
        <source>Select None</source>
        <translation>Vælg intet</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1106"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1101"/>
        <source>High</source>
        <translation>Høj</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Deleforhold:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Genannoncer om:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Sidst set færdige:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Samlet størrelse:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Stykker:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Oprettet af:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Tilføjet den:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Færdig den:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Oprettet den:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Torrent-hash:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Gemmesti:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1096"/>
        <source>Maximum</source>
        <translation>Højeste</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1091"/>
        <source>Do not download</source>
        <translation>Download ikke</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="448"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="455"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (har %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="398"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="401"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 denne session)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="410"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (seedet i %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="417"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 maks.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="430"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="434"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 i alt)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="440"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="445"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 gns.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="589"/>
        <source>Open</source>
        <translation>Åbn</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="592"/>
        <source>Open Containing Folder</source>
        <translation>Åbn indeholdende mappe</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="595"/>
        <source>Rename...</source>
        <translation>Omdøb...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="602"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="661"/>
        <source>New Web seed</source>
        <translation>Nyt webseed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="665"/>
        <source>Remove Web seed</source>
        <translation>Fjern webseed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="670"/>
        <source>Copy Web seed URL</source>
        <translation>Kopiér webseed-URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="673"/>
        <source>Edit Web seed URL</source>
        <translation>Rediger webseed-URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="703"/>
        <source>&lt;center&gt;&lt;b&gt;Speed graphs are disabled&lt;/b&gt;&lt;p&gt;You may change this setting in Advanced Options &lt;/center&gt;</source>
        <translation>&lt;center&gt;&lt;b&gt;Hastighedsgrafer er deaktiveret&lt;/b&gt;&lt;p&gt;Du kan ændre indstillingen i avanceret valgmuligheder &lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="774"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="93"/>
        <source>Filter files...</source>
        <translation>Filterfiler...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="715"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nyt URL-seed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="716"/>
        <source>New URL seed:</source>
        <translation>Nyt URL-seed:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="722"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="775"/>
        <source>This URL seed is already in the list.</source>
        <translation>Dette URL-seed er allerede i listen.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="768"/>
        <source>Web seed editing</source>
        <translation>Redigering af webseed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="769"/>
        <source>Web seed URL:</source>
        <translation>Webseed-URL:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="144"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 er en ukendt kommandolinjeparameter.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="154"/>
        <location filename="../app/main.cpp" line="163"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 skal være en enkelt kommandolinjeparameter.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="192"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Du kan ikke bruge %1: qBittorrent kører allerede for denne bruger.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="518"/>
        <source>Usage:</source>
        <translation>Anvendelse:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="521"/>
        <source>Options:</source>
        <translation>Tilvalg:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="161"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>Parameteren &apos;%1&apos; skal følge syntaksen &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="207"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>Parameteren &apos;%1&apos; skal følge syntaksen &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="221"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>Ventede heltalsnummer i miljøvariablen &apos;%1&apos;, men fik &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="274"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>Parameteren &apos;%1&apos; skal følge syntaksen &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="298"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>Ventede %1 i miljøvariablen &apos;%2&apos;, men fik &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="526"/>
        <source>port</source>
        <translation>port</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="420"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 skal angive en gyldig port (1 til 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="523"/>
        <source>Display program version and exit</source>
        <translation>Vis programversion og afslut</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="525"/>
        <source>Display this help message and exit</source>
        <translation>Vis denne hjælpemeddelelse og afslut</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="527"/>
        <source>Change the Web UI port</source>
        <translation>Skift webgrænsefladeporten</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="530"/>
        <source>Disable splash screen</source>
        <translation>Deaktivér splash-skærm</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="532"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Kør i dæmon-tilstand (i baggrunden)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="535"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>mappe</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="536"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Opbevar konfigurationsfiler i &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="537"/>
        <location filename="../app/cmdoptions.cpp" line="550"/>
        <source>name</source>
        <translation>navn</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Opbevar konfigurationsfiler i mapper ved navn qBittorrent_&lt;navn&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="540"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Hack ind i libtorrent fastresume-filer og gør filstierne relative til profilmappen</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="542"/>
        <source>files or URLs</source>
        <translation>filer eller URL&apos;er</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Download the torrents passed by the user</source>
        <translation>Download torrents som brugeren har givet</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Angiv om &quot;Tilføj ny torrent&quot;-dialogen åbnes når der tilføjes en torrent.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>Options when adding new torrents:</source>
        <translation>Tilvalg når der tilføjes nye torrents:</translation>
    </message>
    <message>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation type="vanished">Genvej for %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>path</source>
        <translation>sti</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>Torrent save path</source>
        <translation>Gemmesti til torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <source>Add torrents as started or paused</source>
        <translation>Tilføj torrents som startet eller sat på pause</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Skip hash check</source>
        <translation>Spring hashtjek over</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Tildel torrents til kategori. Hvis kategorien ikke findes, så oprettes den.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Download files in sequential order</source>
        <translation>Download filer i fortløbende rækkefølge</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>Download first and last pieces first</source>
        <translation>Start med at downloade første og sidste stykker</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Tilvalgsværdier kan gives  via miljøvariabler. For tilvalg ved navn &apos;parameterens-navn&apos;, er miljøvariablens navn &apos;QBT_PARAMETERENS_NAVN&apos; (med store bogstaver, &apos;-&apos; erstattes med &apos;_&apos;). Sæt variablen til &apos;1&apos; eller &apos;TRUE&apos;, for at videregive flag-værdier. F.eks. for at deaktivere splash-skærmen: </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="566"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Kommandolinjeparametre har forrang over miljøvariabler</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="575"/>
        <source>Help</source>
        <translation>Hjælp</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="363"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Kør programmet med tilvalget -h for at læse om kommandolinjeparametre.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="365"/>
        <source>Bad command line</source>
        <translation>Ugyldig kommandolinje</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="371"/>
        <source>Bad command line: </source>
        <translation>Ugyldig kommandolinje: </translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="385"/>
        <source>Legal Notice</source>
        <translation>Juridisk notits</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="386"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation>qBittorrent er et fildelingsprogram. Når du kører en torrent, vil dens data blive gjort tilgængelig til andre via upload. Du har alene ansvaret for det indhold du deler.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="387"/>
        <source>No further notices will be issued.</source>
        <translation>Der udstedes ingen yderligere notitser.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="399"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent er et fildelingsprogram. Når du kører en torrent, vil dens data blive gjort tilgængelig til andre via upload. Du har alene ansvaret for det indhold du deler.

Der udstedes ingen yderlige notitser.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="388"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Tryk på %1 for at acceptere og forsætte...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="400"/>
        <source>Legal notice</source>
        <translation>Juridisk notits</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="401"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="402"/>
        <source>I Agree</source>
        <translation>Jeg accepterer</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="241"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation>Registrerede uren programafslutning. Bruger fallback-fil til at gendanne indstillinger: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="308"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Der opstod en adgangsfejl under forsøg på at skrive konfigurationsfilen.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="311"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Der opstod en formatfejl under forsøg på at skrive konfigurationsfilen.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="314"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation>Der opstod en ukendt fejl ved forsøg på at skrive konfigurationsfilen.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="46"/>
        <source>Migrate preferences failed: WebUI https, file: &quot;%1&quot;, error: &quot;%2&quot;</source>
        <translation>Overføring af præferencer mislykkedes: Webgrænseflade-https, fil: &quot;%1&quot;, fejl: &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../app/upgrade.cpp" line="66"/>
        <source>Migrated preferences: WebUI https, exported data to file: &quot;%1&quot;</source>
        <translation>Overførte præferencer: Webgrænseflade-https, eksporterede data til fil: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="81"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="88"/>
        <source>Invalid data format.</source>
        <translation>Ugyldigt dataformat.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="123"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation>Kunne ikke gemme RSS AutoDownloader-data i %1. Fejl: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="277"/>
        <source>Invalid data format</source>
        <translation>Ugyldigt dataformat</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="419"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation>Kunne ikke læse RSS AutoDownloader-regler fra %1. Fejl: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="431"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation>Kunne ikke læse RSS AutoDownloader-regler. Årsag: %1</translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="206"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Kunne ikke downloade RSS-feed på &apos;%1&apos;. Årsag: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="239"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation>RSS-feed på &apos;%1&apos; opdateret. Tilføjede %2 nye artikler.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="236"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation>Kunne ikke behandle RSS-feed på &apos;%1&apos;. Årsag: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="197"/>
        <source>RSS feed at &apos;%1&apos; is successfully downloaded. Starting to parse it.</source>
        <translation>RSS-feed hos &apos;%1&apos; blev downloadet. Begynder på at fortolke den.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="260"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation>Kunne ikke læse RSS-sessionsdata fra %1. Fejl: %2</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="271"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation>Kunne ikke behandle RSS-sessionsdata. Fejl: %1</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="277"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation>Kunne ikke indlæse RSS-sessionsdata. Ugyldigt dataformat.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="286"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation>Kunne ikke indlæse RSS-artikel &apos;%1#%2&apos;. Ugyldigt dataformat.</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="577"/>
        <source>Invalid RSS feed.</source>
        <translation>Ugyldigt RSS-feed.</translation>
    </message>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="580"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation>%1 (linje: %2, kolonne: %3, forskydning: %4).</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="160"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>RSS-feed med angivne URL findes allerede: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="179"/>
        <source>Cannot move root folder.</source>
        <translation>Kan ikke flytte rodmappe.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="186"/>
        <location filename="../base/rss/rss_session.cpp" line="224"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>Element findes ikke: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="217"/>
        <source>Cannot delete root folder.</source>
        <translation>Kan ikke slette rodmappe.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="379"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Ukorrekt RSS-elementsti: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="385"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>RSS-element med angivne sti findes allerede: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="393"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>Forældermappe findes ikke: %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Søg</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>Hentning af RSS-feeds er nu deaktiveret. Du kan aktivere det i programindstillingerne.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Nyt abonnement</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Mærk elementer som læst</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Genopfrisk RSS-strømme</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Opdater alle</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>RSS-downloader...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (dobbeltklik for at downloade)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Slet</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Omdøb...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Omdøb</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Opdater</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Nyt abonnement...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Opdater alle feeds</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Download torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Åbn nyheds-URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Kopiér URL for feed</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Ny mappe...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="221"/>
        <source>Please choose a folder name</source>
        <translation>Vælg venligst et mappenavn</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="221"/>
        <source>Folder name:</source>
        <translation>Mappenavn:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="222"/>
        <source>New folder</source>
        <translation>Ny mappe</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="262"/>
        <source>Please type a RSS feed URL</source>
        <translation>Skriv venligst en URL for RSS-feed</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="262"/>
        <source>Feed URL:</source>
        <translation>URL for feed:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="303"/>
        <source>Deletion confirmation</source>
        <translation>Bekræftelse for sletning</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="303"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Er du sikker på, at du vil slette de valgte RSS-feeds?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="392"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Vælg venligst et nyt navn til dette RSS-feed</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="392"/>
        <source>New feed name:</source>
        <translation>Nyt feednavn:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="399"/>
        <source>Rename failed</source>
        <translation>Omdøbning mislykkedes</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="462"/>
        <source>Date: </source>
        <translation>Dato: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="464"/>
        <source>Author: </source>
        <translation>Forfatter: </translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="99"/>
        <source>Select save location</source>
        <translation>Vælg placering at gemme</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="150"/>
        <source>Monitored Folder</source>
        <translation>Overvåget mappe</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="153"/>
        <source>Override Save Location</source>
        <translation>Tilsidesæt placering at gemme</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="394"/>
        <source>Monitored folder</source>
        <translation>Overvåget mappe</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="396"/>
        <source>Default save location</source>
        <translation>Standardplacering at gemme</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="398"/>
        <source>Browse...</source>
        <translation>Gennemse...</translation>
    </message>
</context>
<context>
    <name>SearchController</name>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="169"/>
        <location filename="../webui/api/searchcontroller.cpp" line="175"/>
        <source>Offset is out of range</source>
        <translation>Forskydning er udenfor område</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="264"/>
        <source>All plugins are already up to date.</source>
        <translation>Alle plugins er allerede af nyeste udgave.</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="268"/>
        <source>Updating %1 plugins</source>
        <translation>Opdaterer %1 plugins</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="272"/>
        <source>Updating plugin %1</source>
        <translation>Opdaterer pluginet %1</translation>
    </message>
    <message>
        <location filename="../webui/api/searchcontroller.cpp" line="279"/>
        <source>Failed to check for plugin updates: %1</source>
        <translation>Kunne ikke søge efter plugin-opdateringer: %1</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Resultater(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="45"/>
        <source>Search in:</source>
        <translation>Søg i:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Nogle søgemotorer søger i torrentbeskrivelser og også i torrentnavne. Hvorvidt sådanne resultater vil blive vist i listen herunder styres af denne tilstand.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Alle steder&lt;/span&gt; deaktivere filtrering og viser alt som returneres af søgemotorene.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kun torrentnavne&lt;/span&gt; viser kun torrents hvis navn matcher søgeforespørgsel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sæt minimum og maksimum tilladte antal seedere&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="87"/>
        <source>Seeds:</source>
        <translation>Seeds:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimum antal seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="116"/>
        <location filename="../gui/search/searchjobwidget.ui" line="204"/>
        <source>to</source>
        <translation>til</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maksimum antal seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="126"/>
        <location filename="../gui/search/searchjobwidget.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sæt minimum og maksimum tilladte størrelse af en torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="170"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimum torrentstørrelse&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maksimum torrentstørrelse&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="78"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="79"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="80"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Seedere</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="81"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Leechere</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="82"/>
        <source>Search engine</source>
        <translation>Søgemotor</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="132"/>
        <source>Filter search results...</source>
        <translation>Filtrer søgeresultater...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="303"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Resultater (viser &lt;i&gt;%1&lt;/i&gt; ud af &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="354"/>
        <source>Torrent names only</source>
        <translation>Kun torrentnavne</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="355"/>
        <source>Everywhere</source>
        <translation>Alle steder</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="378"/>
        <source>Use regular expressions</source>
        <translation>Brug regulære udtryk</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="393"/>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="399"/>
        <source>Open description page</source>
        <translation>Åbn beskrivelsesside</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="403"/>
        <source>Copy</source>
        <translation>Kopiér</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="406"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="410"/>
        <source>Download link</source>
        <translation>Downloadlink</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="415"/>
        <source>Description page URL</source>
        <translation>URL for beskrivelsesside</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="425"/>
        <source>Searching...</source>
        <translation>Søger...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="427"/>
        <source>Search has finished</source>
        <translation>Søgningen er færdig</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="429"/>
        <source>Search aborted</source>
        <translation>Søgning afbrudt</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="431"/>
        <source>An error occurred during search...</source>
        <translation>Der opstod en fejl under søgningen...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="433"/>
        <source>Search returned no results</source>
        <translation>Søgningen gav ingen resultater</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="458"/>
        <source>Column visibility</source>
        <translation>Synlighed for kolonne</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../gui/search/searchlistdelegate.cpp" line="59"/>
        <source>Unknown</source>
        <translation>Ukendt</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="211"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Ukendt filformat for søgemotor-plugin.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="222"/>
        <source>Plugin already at version %1, which is greater than %2</source>
        <translation>Pluginet er allerede version %1, hvilket er større end %2</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="223"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>En nyere version af dette plugin er allerede installeret.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="244"/>
        <source>Plugin %1 is not supported.</source>
        <translation>Pluginet %1 understøttes ikke.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="251"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="254"/>
        <source>Plugin is not supported.</source>
        <translation>Plugin understøttes ikke.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="260"/>
        <source>Plugin %1 has been successfully updated.</source>
        <translation>Pluginet %1 blev opdateret.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="322"/>
        <source>All categories</source>
        <translation>Alle kategorier</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="323"/>
        <source>Movies</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="324"/>
        <source>TV shows</source>
        <translation>TV-shows</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="325"/>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="326"/>
        <source>Games</source>
        <translation>Spil</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="327"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="328"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="329"/>
        <source>Pictures</source>
        <translation>Billeder</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="330"/>
        <source>Books</source>
        <translation>Bøger</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="365"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>Opdateringsserveren er midlertidig utilgængelig. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="384"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="386"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Kunne ikke download plugin-filen. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="513"/>
        <source>Plugin &quot;%1&quot; is outdated, updating to version %2</source>
        <translation>Pluginet &quot;%1&quot; er forældet, opdaterer til version %2</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="519"/>
        <source>Incorrect update info received for %1 out of %2 plugins.</source>
        <translation>Ukorrekt opdateringsinformation modtaget til %1 ud af %2 plugins.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="556"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>Søge-pluginet &apos;%1&apos; indeholder ugyldig versionsstreng (&apos;%2&apos;)</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="252"/>
        <location filename="../gui/search/searchwidget.cpp" line="272"/>
        <location filename="../gui/search/searchwidget.cpp" line="335"/>
        <location filename="../gui/search/searchwidget.cpp" line="343"/>
        <source>Search</source>
        <translation>Søg</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>Der er ikke installeret nogen søge-plugins.
Klik på &quot;Søg efter plugins...&quot;-knappen nederst til højre i vinduet, for at installere nogen.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Search plugins...</source>
        <translation>Søge-plugins...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="90"/>
        <source>A phrase to search for.</source>
        <translation>Søg efter en frase.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="91"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Mellemrum i søgetermner kan beskyttes med dobbelte anførselstegn.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="93"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Eksempel:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="95"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: søg efter &lt;b&gt;foo&lt;/b&gt; og &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="99"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: søg efter &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="168"/>
        <source>All plugins</source>
        <translation>Alle plugins</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="167"/>
        <source>Only enabled</source>
        <translation>Kun aktiverede</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="169"/>
        <source>Select...</source>
        <translation>Vælg...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="265"/>
        <location filename="../gui/search/searchwidget.cpp" line="329"/>
        <location filename="../gui/search/searchwidget.cpp" line="331"/>
        <source>Search Engine</source>
        <translation>Søgemotor</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="265"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Installer venligst Python for at bruge søgemotoren.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="282"/>
        <source>Empty search pattern</source>
        <translation>Tomt søgemønster</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="282"/>
        <source>Please type a search pattern first</source>
        <translation>Skriv venligst først et søgemønster</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="312"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="331"/>
        <source>Search has finished</source>
        <translation>Søgningen er færdig</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="329"/>
        <source>Search has failed</source>
        <translation>Søgningen mislykkedes</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>Vis ikke igen</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="112"/>
        <source>qBittorrent will now exit.</source>
        <translation>qBittorrent vil nu afslutte.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="113"/>
        <source>E&amp;xit Now</source>
        <translation>&amp;Afslut nu</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>Exit confirmation</source>
        <translation>Bekræftelse for afslut</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="117"/>
        <source>The computer is going to shutdown.</source>
        <translation>Computeren lukker ned.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="118"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Luk ned nu</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>Shutdown confirmation</source>
        <translation>Bekræftelse for nedlukning</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="122"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>Computeren går i suspenderingstilstand.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="123"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Suspendér nu</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>Suspend confirmation</source>
        <translation>Bekræftelse for suspendering</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="127"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>Computeren går i dvaletilstand.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="128"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Dvale nu</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>Hibernate confirmation</source>
        <translation>Bekræftelse for dvale</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="139"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Du kan annullere handlingen indenfor %1 sekunder.</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="26"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/speedlimitdialog.ui" line="29"/>
        <source> KiB/s</source>
        <translation> KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="175"/>
        <source>Total Upload</source>
        <translation>Samlet upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="176"/>
        <source>Total Download</source>
        <translation>Samlet download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="180"/>
        <source>Payload Upload</source>
        <translation>Nyttelast upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="181"/>
        <source>Payload Download</source>
        <translation>Nyttelast download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="185"/>
        <source>Overhead Upload</source>
        <translation>Overhead upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="186"/>
        <source>Overhead Download</source>
        <translation>Overhead download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="190"/>
        <source>DHT Upload</source>
        <translation>DHT upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="191"/>
        <source>DHT Download</source>
        <translation>DHT download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="195"/>
        <source>Tracker Upload</source>
        <translation>Tracker upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="196"/>
        <source>Tracker Download</source>
        <translation>Tracker download</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Periode:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minutter</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minutter</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 timer</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="103"/>
        <source>Select Graphs</source>
        <translation>Vælg grafer</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Total Upload</source>
        <translation>Samlet upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="75"/>
        <source>12 Hours</source>
        <translation>12 timer</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="76"/>
        <source>24 Hours</source>
        <translation>24 timer</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Total Download</source>
        <translation>Samlet download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Payload Upload</source>
        <translation>Nyttelast upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Payload Download</source>
        <translation>Nyttelast download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>Overhead Upload</source>
        <translation>Overhead upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>Overhead Download</source>
        <translation>Overhead download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>DHT Upload</source>
        <translation>DHT upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>DHT Download</source>
        <translation>DHT download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="90"/>
        <source>Tracker Upload</source>
        <translation>Tracker upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="91"/>
        <source>Tracker Download</source>
        <translation>Tracker download</translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation>Nedbrudsinfo</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Statistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Brugerstatistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Mellemlagerstatistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Læsemellemlagerets træffere:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Gennemsnitlig tid i kø:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>Tilsluttede modparter:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation>Deleforhold igennem tiden:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation>Download igennem tiden:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation>Sessionsspild:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation>Upload igennem tiden:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation>Samlet bufferstørrelse:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Ydelsesstatistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>I/O-jobs i kø:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Overbelastet skrivemellemlager:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Overbelastet læsemellemlager:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Samlet størrelse i kø:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="110"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="67"/>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>Connection status:</source>
        <translation>Forbindelsesstatus:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="187"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Ingen direkte forbindelser. Dette kan indikere problemer med at konfigurere netværket.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="89"/>
        <location filename="../gui/statusbar.cpp" line="196"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 knudepunkter</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="160"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>qBittorrent skal genstartes!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="177"/>
        <location filename="../gui/statusbar.cpp" line="183"/>
        <source>Connection Status:</source>
        <translation>Forbindelsesstatus:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="177"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. Dette betyder typisk at qBittorrent ikke kunne lytte efter indgående forbindelser på den valgte port.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="183"/>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="239"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Klik for at skifte til alternative grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="234"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Klik for at skifte til normale grænser for hastighed</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="251"/>
        <source>Global Download Speed Limit</source>
        <translation>Global grænse for downloadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="265"/>
        <source>Global Upload Speed Limit</source>
        <translation>Global grænse for uploadhastighed</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Alle (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="161"/>
        <source>Downloading (0)</source>
        <translation>Downloader (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="164"/>
        <source>Seeding (0)</source>
        <translation>Seeder (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="167"/>
        <source>Completed (0)</source>
        <translation>Færdige (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="170"/>
        <source>Resumed (0)</source>
        <translation>Genoptaget (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="173"/>
        <source>Paused (0)</source>
        <translation>Sat på pause (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="176"/>
        <source>Active (0)</source>
        <translation>Aktive (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="179"/>
        <source>Inactive (0)</source>
        <translation>Inaktive (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="182"/>
        <source>Errored (0)</source>
        <translation>Fejlramte (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="226"/>
        <source>All (%1)</source>
        <translation>Alle (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="227"/>
        <source>Downloading (%1)</source>
        <translation>Downloader (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="228"/>
        <source>Seeding (%1)</source>
        <translation>Seeder (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="229"/>
        <source>Completed (%1)</source>
        <translation>Færdige (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="231"/>
        <source>Paused (%1)</source>
        <translation>Sat på pause (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="230"/>
        <source>Resumed (%1)</source>
        <translation>Genoptaget (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="232"/>
        <source>Active (%1)</source>
        <translation>Aktive (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="233"/>
        <source>Inactive (%1)</source>
        <translation>Inaktive (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="234"/>
        <source>Errored (%1)</source>
        <translation>Fejlramte (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="147"/>
        <source>Tags</source>
        <translation>Mærkater</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="258"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>Untagged</source>
        <translation>Uden mærkat</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="112"/>
        <source>Add tag...</source>
        <translation>Tilføj mærkat...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="119"/>
        <source>Remove tag</source>
        <translation>Fjern mærkat</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="125"/>
        <source>Remove unused tags</source>
        <translation>Fjern ubrugte mærkater</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="132"/>
        <source>Resume torrents</source>
        <translation>Genoptag torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="138"/>
        <source>Pause torrents</source>
        <translation>Sæt torrents på pause</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="144"/>
        <source>Delete torrents</source>
        <translation>Slet torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="187"/>
        <source>New Tag</source>
        <translation>Nyt mærkat</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="187"/>
        <source>Tag:</source>
        <translation>Mærkat:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="191"/>
        <source>Invalid tag name</source>
        <translation>Ugyldigt mærkatnavn</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>Mærkatnavnet &apos;%1&apos; er ugyldigt</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="207"/>
        <source>Tag exists</source>
        <translation>Mærkatet findes</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="207"/>
        <source>Tag name already exists.</source>
        <translation>Mærkatnavnet findes allerede.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Egenskaber for torrentkategori</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Gemmesti:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="42"/>
        <source>Choose save path</source>
        <translation>Vælg gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="57"/>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="66"/>
        <source>Invalid category name</source>
        <translation>Ugyldigt kategorinavn</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>Kategorinavn må ikke indeholde &apos;\&apos;.
Kategorinavn må ikke begynde/slutte med &apos;/&apos;.
Kategorinavn må ikke indeholde &apos;//&apos;-sekvens.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="73"/>
        <source>Category creation error</source>
        <translation>Fejl ved oprettelse af kategori</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Der findes allerede en kategori med det angivne navn.
Vælg venligst et andet navn og prøv igen.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="183"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="183"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="183"/>
        <source>Progress</source>
        <translation>Forløb</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="183"/>
        <source>Download Priority</source>
        <translation>Downloadprioritet</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="183"/>
        <source>Remaining</source>
        <translation>Tilbage</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="183"/>
        <source>Availability</source>
        <translation>Tilgængelighed</translation>
    </message>
</context>
<context>
    <name>TorrentContentTreeView</name>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="107"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="226"/>
        <source>Renaming</source>
        <translation>Omdøber</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="107"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="226"/>
        <source>New name:</source>
        <translation>Nyt navn:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="112"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="140"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="231"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="255"/>
        <source>Rename error</source>
        <translation>Fejl ved omdøbning</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="113"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="232"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>Navnet er tomt eller indeholder forbudte tegn. Vælg venligst et andet.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="141"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="256"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Navnet bruges allerede i denne mappe. Brug venligst et andet navn.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="180"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="295"/>
        <source>The folder could not be renamed</source>
        <translation>Mappen kunne ikke omdøbes</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontenttreeview.cpp" line="181"/>
        <location filename="../gui/torrentcontenttreeview.cpp" line="296"/>
        <source>This name is already in use. Please use a different name.</source>
        <translation>Navnet bruges allerede. Brug venligst et andet navn.</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Torrentopretter</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation>Vælg fil/mappe som skal deles</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="31"/>
        <source>Path:</source>
        <translation>Sti:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation>[Træk-og-slip-område]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="68"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="111"/>
        <source>Select file</source>
        <translation>Vælg fil</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="75"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="104"/>
        <source>Select folder</source>
        <translation>Vælg mappe</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="87"/>
        <source>Settings</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="95"/>
        <source>Piece size:</source>
        <translation>Stykstørrelse:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="109"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="114"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="119"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="124"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="129"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="134"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="139"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="144"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="149"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="159"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="164"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="169"/>
        <source>32 MiB</source>
        <translation>32 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="177"/>
        <source>Calculate number of pieces:</source>
        <translation>Udregn antal stykker:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="206"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>Privat torrent (distribueres ikke på DHT-netværk)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="213"/>
        <source>Start seeding immediately</source>
        <translation>Start seeding med det samme</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="223"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorer grænser for deleforhold for denne torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="230"/>
        <source>Optimize alignment</source>
        <translation>Optimer justering</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="241"/>
        <source>Align to piece boundary for files larger than:</source>
        <translation>Juster til stykgrænse for filer som er større end:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="248"/>
        <source>Disabled</source>
        <translation>Deaktiveret</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="251"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="288"/>
        <source>Fields</source>
        <translation>Felter</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="294"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Du kan separere tracker-tiers/-grupper med en tom linje.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="304"/>
        <source>Web seed URLs:</source>
        <translation>Web seed-URL&apos;er:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="325"/>
        <source>Tracker URLs:</source>
        <translation>Tracker-URL&apos;er:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="332"/>
        <source>Comments:</source>
        <translation>Kommentarer:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="339"/>
        <source>Source:</source>
        <translation>Kilde:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="354"/>
        <source>Progress:</source>
        <translation>Forløb:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="70"/>
        <source>Create Torrent</source>
        <translation>Opret torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="154"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="193"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="205"/>
        <source>Torrent creation failed</source>
        <translation>Oprettelse af torrent mislykkedes</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="154"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Årsag: Sti til fil/mappe kan ikke læses.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="161"/>
        <source>Select where to save the new torrent</source>
        <translation>Vælg hvor den nye torrent skal gemmes</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="161"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Torrent-filer (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="193"/>
        <source>Reason: %1</source>
        <translation>Årsag: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="205"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>Årsag: Oprettede torrent er ugyldig. Den vil ikke blive tilføjet til downloadlisten.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="217"/>
        <source>Torrent creator</source>
        <translation>Torrentopretter</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="218"/>
        <source>Torrent created:</source>
        <translation>Torrent oprettet:</translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="130"/>
        <source>File size exceeds max limit %1</source>
        <translation>Filstørrelsen overstiger maks. grænse %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="140"/>
        <source>Torrent file read error: %1</source>
        <translation>Læsefejl ved torrent-fil: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="145"/>
        <source>Torrent file read error: size mismatch</source>
        <translation>Læsefejl ved torrent-fil: uoverensstemmelse i størrelse</translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="595"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation>Fejl: &apos;%1&apos; er ikke en gyldig torrent-fil.</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="755"/>
        <source>Priority must be an integer</source>
        <translation>Prioritet skal være et heltal</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="758"/>
        <source>Priority is not valid</source>
        <translation>Prioritet er ikke gyldig</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="764"/>
        <source>Torrent&apos;s metadata has not yet downloaded</source>
        <translation>Torrentens metadata er endnu ikke downloadet</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="772"/>
        <source>File IDs must be integers</source>
        <translation>Fil-id&apos;er skal være heltal</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="774"/>
        <source>File ID is not valid</source>
        <translation>Fil-id er ikke gyldig</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="911"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="922"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="933"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="944"/>
        <source>Torrent queueing must be enabled</source>
        <translation>Torrent-forespørgsel må ikke være aktiveret</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="958"/>
        <source>Save path cannot be empty</source>
        <translation>Gemmesti må ikke være tom</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1045"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1062"/>
        <source>Category cannot be empty</source>
        <translation>Kategori må ikke være tom</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1051"/>
        <source>Unable to create category</source>
        <translation>Kan ikke oprette kategori</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1065"/>
        <source>Unable to edit category</source>
        <translation>Kan ikke redigere kategori</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1169"/>
        <source>Name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1171"/>
        <source>Name is not valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1178"/>
        <source>ID is not valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1195"/>
        <source>Name is already in use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="962"/>
        <source>Cannot make save path</source>
        <translation>Kan ikke oprette gemmesti</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="966"/>
        <source>Cannot write to directory</source>
        <translation>Kan ikke skrive til mappe</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="970"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>Webgrænseflade sæt placering: flytter &quot;%1&quot;, fra &quot;%2&quot; til &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="984"/>
        <source>Incorrect torrent name</source>
        <translation>Ukorrekt torrentnavn</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="1033"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="1048"/>
        <source>Incorrect category name</source>
        <translation>Ukorrekt kategorinavn</translation>
    </message>
</context>
<context>
    <name>TrackerEntriesDialog</name>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="14"/>
        <source>Edit trackers</source>
        <translation>Rediger trackere</translation>
    </message>
    <message>
        <location filename="../gui/trackerentriesdialog.ui" line="20"/>
        <source>One tracker URL per line.

- You can split the trackers into groups by inserting blank lines.
- All trackers within the same group will belong to the same tier.
- The group on top will be tier 0, the next group tier 1 and so on.
- Below will show the common subset of trackers of the selected torrents.</source>
        <translation>Én tracker-URL pr. linje.

- Du kan opdele trackerne i grupper ved at indsætte tomme linjer.
- Alle trackere i den samme gruppe vil tilhører den samme tier.
- Den øverste gruppe er tier 0, den næste gruppe er tier 1 osv.
- Nedenfor vises fælles undersæt af trackere for de valgte torrents.</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="254"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Alle (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="257"/>
        <source>Trackerless (0)</source>
        <translation>Trackerløs (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="260"/>
        <source>Error (0)</source>
        <translation>Fejl (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="263"/>
        <source>Warning (0)</source>
        <translation>Advarsel (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="308"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="363"/>
        <source>Trackerless (%1)</source>
        <translation>Trackerløs (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="405"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="437"/>
        <source>Error (%1)</source>
        <translation>Fejl (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="418"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="452"/>
        <source>Warning (%1)</source>
        <translation>Advarsel (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="504"/>
        <source>Resume torrents</source>
        <translation>Genoptag torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="507"/>
        <source>Pause torrents</source>
        <translation>Sæt torrents på pause</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="510"/>
        <source>Delete torrents</source>
        <translation>Slet torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="535"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="549"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Alle (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="276"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="370"/>
        <source>Working</source>
        <translation>Arbejder</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="277"/>
        <source>Disabled</source>
        <translation>Deaktiveret</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="298"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="163"/>
        <source>This torrent is private</source>
        <translation>Denne torrent er privat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="374"/>
        <source>Updating...</source>
        <translation>Opdaterer...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="378"/>
        <source>Not working</source>
        <translation>Arbejder ikke</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="382"/>
        <source>Not contacted yet</source>
        <translation>Ikke kontaktet endnu</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="390"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="393"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="396"/>
        <source>N/A</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="486"/>
        <source>Tracker editing</source>
        <translation>Redigering af tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="486"/>
        <source>Tracker URL:</source>
        <translation>Tracker-URL:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="491"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="500"/>
        <source>Tracker editing failed</source>
        <translation>Redigering af tracker mislykkedes</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="491"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>Den indtastede tracker-URL er ugyldig.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="500"/>
        <source>The tracker URL already exists.</source>
        <translation>Tracker-URL&apos;en findes allerede.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="556"/>
        <source>Add a new tracker...</source>
        <translation>Tilføj en ny tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="560"/>
        <source>Edit tracker URL...</source>
        <translation>Rediger tracker-URL...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="563"/>
        <source>Remove tracker</source>
        <translation>Fjern tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="566"/>
        <source>Copy tracker URL</source>
        <translation>Kopiér tracker-URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="571"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Tving genannoncering til valgte trackere</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="576"/>
        <source>Force reannounce to all trackers</source>
        <translation>Tving genannoncering til alle trackere</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="601"/>
        <source>Tier</source>
        <translation>Tier</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="602"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="603"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="605"/>
        <source>Seeds</source>
        <translation>Seeds</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="604"/>
        <source>Peers</source>
        <translation>Modparter</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="606"/>
        <source>Leeches</source>
        <translation>Leechere</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="607"/>
        <source>Downloaded</source>
        <translation>Downloadet</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="608"/>
        <source>Message</source>
        <translation>Meddelelse</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="627"/>
        <source>Column visibility</source>
        <translation>Synlighed for kolonne</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Tilføjelse af tracker-dialog</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Liste over trackere der skal tilføjes (en pr. linje):</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>Liste-URL som er kompatibel med µTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="124"/>
        <source>No change</source>
        <translation>Ingen ændring</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="124"/>
        <source>No additional trackers were found.</source>
        <translation>Ingen yderligere trackere blev fundet.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="86"/>
        <source>Download error</source>
        <translation>Fejl ved download</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="87"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>Trackerlisten kunne ikke downloades, årsag: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="249"/>
        <source>Downloading</source>
        <translation>Downloader</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="257"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Allokerer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="272"/>
        <source>Paused</source>
        <translation>Sat på pause</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="260"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Seeder</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="251"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Gået i stå</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="268"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Tjekker</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="253"/>
        <source>Downloading metadata</source>
        <comment>Used when loading a magnet link</comment>
        <translation>Downloader metadata</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="255"/>
        <source>[F] Downloading</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Downloader</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="262"/>
        <source>[F] Seeding</source>
        <comment>Used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Seeder</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="265"/>
        <source>Queued</source>
        <comment>Torrent is queued</comment>
        <translation>Sat i kø</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="270"/>
        <source>Checking resume data</source>
        <comment>Used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Tjekker genoptagelsesdata</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="274"/>
        <source>Completed</source>
        <translation>Færdige</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="276"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>Flytter</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="278"/>
        <source>Missing Files</source>
        <translation>Manglende filer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="280"/>
        <source>Errored</source>
        <comment>Torrent status, the torrent has an error</comment>
        <translation>Fejlramte</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="132"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (seedet i %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="195"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 siden</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="628"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="636"/>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="655"/>
        <source>Tags</source>
        <translation>Mærkater</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="673"/>
        <source>Trackers</source>
        <translation>Trackere</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="96"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="97"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="98"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Færdig</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="99"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="100"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seeds</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="101"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Modparter</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="102"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Downloadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="103"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Uploadhastighed</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="104"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Forhold</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="105"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>ETA</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="106"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="107"/>
        <source>Tags</source>
        <translation>Mærkater</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="108"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Tilføjet den</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="109"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Færdig den</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="110"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="111"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Downloadgrænse</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Uploadgrænse</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Downloadet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Uploadet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Downloadet i session</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Uploadet i session</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Tilbage</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tid aktiv</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Færdig</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Grænse for forhold</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Sidst set færdige</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Sidste aktivitet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Samlet størrelse</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Availability</source>
        <comment>The number of distributed copies of the torrent</comment>
        <translation>Tilgængelighed</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="650"/>
        <source>Column visibility</source>
        <translation>Synlighed for kolonne</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="320"/>
        <source>Choose save path</source>
        <translation>Vælg gemmesti</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="557"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Begrænsning af hastighed ved download af torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="582"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Begrænsning af hastighed ved upload af torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="631"/>
        <source>Recheck confirmation</source>
        <translation>Bekræftelse for gentjek</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="631"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Er du sikker på, at du vil gentjekke den valgte torrent(s)?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="815"/>
        <source>Rename</source>
        <translation>Omdøb</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="815"/>
        <source>New name:</source>
        <translation>Nyt navn:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="854"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Genoptag</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="858"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Tving genoptag</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="856"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Sæt på pause</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="327"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation>Sæt placering: flytter &quot;%1&quot;, fra &quot;%2&quot; til &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="531"/>
        <source>Unable to preview</source>
        <translation>Kan ikke forhåndsvise</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="531"/>
        <source>The selected torrent &quot;%1&quot; does not contain previewable files</source>
        <translation>Den valgte torrent &quot;%1&quot; indeholder ikke filer som kan forhåndsvises</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="724"/>
        <source>Add Tags</source>
        <translation>Tilføj mærkater</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="765"/>
        <source>Remove All Tags</source>
        <translation>Fjern alle mærkater</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="765"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Fjern alle mærkater fra valgte torrents?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="779"/>
        <source>Comma-separated tags:</source>
        <translation>Kommasepareret mærkater:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="786"/>
        <source>Invalid tag</source>
        <translation>Ugyldigt mærkat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="787"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>Mærkatnavnet &apos;%1&apos; er ugyldigt</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="860"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Slet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="862"/>
        <source>Preview file...</source>
        <translation>Forhåndsvis fil...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="864"/>
        <source>Limit share ratio...</source>
        <translation>Begræns deleforhold...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="866"/>
        <source>Limit upload rate...</source>
        <translation>Begræns uploadhastighed...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="868"/>
        <source>Limit download rate...</source>
        <translation>Begræns downloadhastighed...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="870"/>
        <source>Open destination folder</source>
        <translation>Åbn destinationsmappe</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="872"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Flyt op</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="874"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Flyt ned</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="876"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Flyt til toppen</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="878"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Flyt til bunden</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="880"/>
        <source>Set location...</source>
        <translation>Sæt placering...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="884"/>
        <source>Force reannounce</source>
        <translation>Tving genannoncer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="886"/>
        <source>Magnet link</source>
        <translation>Magnet-link</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="888"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="890"/>
        <source>Hash</source>
        <translation>Hash</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1116"/>
        <source>Queue</source>
        <translation>Kø</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1124"/>
        <source>Copy</source>
        <translation>Kopiér</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="898"/>
        <source>Download first and last pieces first</source>
        <translation>Start med at downloade første og sidste stykker</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="900"/>
        <source>Automatic Torrent Management</source>
        <translation>Automatisk torrent-håndtering</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="901"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automatisk tilstand betyder at diverse torrent-egenskaber (f.eks. gemmesti) vil blive besluttet af den tilknyttede kategori</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="903"/>
        <source>Edit trackers...</source>
        <translation>Rediger trackere...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1007"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1009"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Ny...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1012"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Nulstil</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1034"/>
        <source>Tags</source>
        <translation>Mærkater</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1036"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Tilføj...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1039"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Fjern alle</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="882"/>
        <source>Force recheck</source>
        <translation>Tving gentjek</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="892"/>
        <source>Super seeding mode</source>
        <translation>Super seeding-tilstand</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="894"/>
        <source>Rename...</source>
        <translation>Omdøb...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="896"/>
        <source>Download in sequential order</source>
        <translation>Download i fortløbende rækkefølge</translation>
    </message>
</context>
<context>
    <name>UIThemeManager</name>
    <message>
        <location filename="../gui/uithememanager.cpp" line="63"/>
        <source>Failed to load UI theme from file: &quot;%1&quot;</source>
        <translation>Kunne ikke indlæse brugefladetema fra fil: &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../gui/uithememanager.cpp" line="85"/>
        <source>Couldn&apos;t apply theme stylesheet. stylesheet.qss couldn&apos;t be opened. Reason: %1</source>
        <translation>Kunne ikke anvende tematypografiark. stylesheet.qss kunne ikke åbnes. Årsag: %1</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Begrænsning af upload-/download-forhold for torrent</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="20"/>
        <source>Use global share limit</source>
        <translation>Brug global delegrænse</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="23"/>
        <location filename="../gui/updownratiodialog.ui" line="33"/>
        <location filename="../gui/updownratiodialog.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>knapGruppe</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="30"/>
        <source>Set no share limit</source>
        <translation>Sæt ingen delegrænse</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="42"/>
        <source>Set share limit to</source>
        <translation>Sæt delegrænse til</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="100"/>
        <source>ratio</source>
        <translation>forhold</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="107"/>
        <source>minutes</source>
        <translation>minutter</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="85"/>
        <source>No share limit method selected</source>
        <translation>Ingen delegrænsemetode valgt</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="86"/>
        <source>Please select a limit method first</source>
        <translation>Vælg venligst først en grænsemetode</translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="81"/>
        <source>Python detected, executable name: &apos;%1&apos;, version: %2</source>
        <translation>Python registreret, navn på eksekverbar: &apos;%1&apos;, version: %2</translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="271"/>
        <source>Python not detected</source>
        <translation>Python ikke registreret</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="178"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation>Uacceptabel filtype. Kun almindelig fil er tilladt.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="185"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation>Symlinks i alternativ brugerflademappe er forbudt.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="310"/>
        <source>Using built-in Web UI.</source>
        <translation>Bruger indbygget webgrænseflade.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="312"/>
        <source>Using custom Web UI. Location: &quot;%1&quot;.</source>
        <translation>Bruger tilpasset webgrænseflade. Placering: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="322"/>
        <source>Web UI translation for selected locale (%1) has been successfully loaded.</source>
        <translation>Webgrænsefladen for den valgte lokalitet (%1) er indlæst.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="326"/>
        <source>Couldn&apos;t load Web UI translation for selected locale (%1).</source>
        <translation>Kunne ikke indlæse oversættelsen til webgrænsefladen for den valgte lokalitet (%1).</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="384"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation>Den maksimale filstørrelse er oversteget (%1)!</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="585"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>Webgrænseflade: Origin-header og target-oprindelse matcher ikke! Kilde-IP: &apos;%1&apos;. Origin-header: &apos;%2&apos;. Target-oprindelse: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="594"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>Webgrænseflade: Referer-header og target-oprindelse matcher ikke! Kilde-IP: &apos;%1&apos;. Referer-header: &apos;%2&apos;. Target-oprindelse: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="611"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation>Webgrænseflade: Ugyldig værtsheader, port matcher ikke. Anmodningens kilde-IP: &apos;%1&apos;. Serverport: &apos;%2&apos;. Modtog værtsheader: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="631"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation>Webgrænseflade: Ugyldig værtsheader. Anmodningens kilde-IP: &apos;%1&apos;. Modtog værtsheader: &apos;%2&apos;</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="96"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Webgrænseflade: HTTPS-opsætning lykkedes</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="98"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Webgrænseflade: HTTPS-opsætning mislykkedes, falder tilbage til HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="109"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>Webgrænseflade: Lytter nu på IP: %1, port: %2</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="112"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Webgrænseflade: Kan ikke binde til IP: %1, port: %2. Årsag: %3</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="66"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="67"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="68"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="69"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="70"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="71"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="72"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="235"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="342"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1 t %2 m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="348"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1 d %2 t</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="353"/>
        <source>%1y %2d</source>
        <comment>e.g: 2years 10days</comment>
        <translation>%1å %2d</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="244"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Ukendt</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="128"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent vil nu lukke computeren da alle downloads er færdige.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="333"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="337"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 m</translation>
    </message>
</context>
</TS>
